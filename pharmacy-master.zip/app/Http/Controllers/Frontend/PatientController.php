<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Patient;
use App\Subscription;

class PatientController extends Controller
{
    public function dashboard(){
        $user_id=auth()->user()->id;
        $patient=Patient::where('user_id',$user_id)->firstOrFail();
        return view('Backend.Patient.index')->with(['patient'=>$patient]);
    }

    public function index(){
        $user_id=auth()->user()->id;
        $patient=Patient::where('user_id',$user_id)->firstOrFail();
        return view('Backend.Patient.subscription')->with(['patient'=>$patient]);       
    }

    public function edit(Subscription $subscription){
        return view('Backend.Patient.subscription_edit')->with(['subscription'=>$subscription]);
    }

    public function update(Request $request,Subscription $subscription){
        $input=$request->all();
        $subscription->update([
            'previous_status'=>$subscription->subscription_status_id,
            'edited_duration'=>$input['edited_duration'],
            'notes_for_doctor_edit'=>$input['notes_for_doctor_edit'],
            'subscription_status_id'=>6,
            'pending_reactivation'=>2,
            'is_edited'=>1
            ]);
        return redirect()->route('subscription-patient')->with('success','Successfully edited');
    }

    public function post_cancel(Request $request,Subscription $subscription){
        $subscription->update([
            'subscription_status_id'=>5,
            'pending_reactivation'=>2,
        ]);
        return redirect()->back()->with('success','Successfully canceled the subscription');
    }

    public function pause(Subscription $subscription){
        return view('Backend.Patient.subscription_pause')->with(['subscription'=>$subscription]);
    } 

    public function post_pause(Request $request,Subscription $subscription){
        $subscription->update([
            'subscription_status_id'=>4,
            'pending_reactivation'=>2,
            'notes_for_doctor_pause'=>$request->input('notes_for_doctor_pause')
        ]);
        return redirect()->route('subscription-patient')->with('success','Successfully Paused the subscription');
    }

    public function reactivate(Subscription $subscription){
        return view('Backend.Patient.subscription_reactivate')->with(['subscription'=>$subscription]);
    }

    public function post_reactivate(Request $request,Subscription $subscription){

        $input=$request->input('notes_for_doctor_reactivate');
        $subscription->update([
            'subscription_status_id'=>3,
            'notes_for_doctor_reactivate'=>$input,
            'pending_reactivation'=> 1
        ]);
   
        return redirect()->route('subscription-patient')->with('success','Successfully send the request for Reactivation.Please wait for the response');
    }
}
