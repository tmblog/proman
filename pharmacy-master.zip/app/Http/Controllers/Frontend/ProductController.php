<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\Pack;
use App\Answer;
use Datetime;

class ProductController extends Controller
{
    protected $product;

    public function __construct(Product $product,Category $category){
        $this->product=$product;
    }

    public function index(Category $category){
        $products=Product::where('category_id',$category['id'])->get()->toArray();
        return view('Frontend.products')->with(['products'=>$products,'category'=>$category]);
    }

    public function show(Category $category,Product $product){
        $product=Product::with('packs')->where('slug',$product['slug'])->firstOrFail();
        return view('Frontend.product_details')->with(['product'=>$product,'category'=>$category]);
    }

    public function product_questions(Category $category,Product $product,Pack $pack){
        $product=Product::with(['questions'=>function($query){
            $query->with('options');
        }])->where('slug',$product['slug'])->firstOrFail()->toArray();
        return view('Backend.questions')->with(['product'=>$product,'category'=>$category,'pack'=>$pack]);
    }

    public function treatment(Category $category, Request $request){
        if(\Auth::check()){
            $user_id=auth()->user()->id;
            if($this->is_consultation_expired($user_id,$category->id)){
                abort(404);
            }
        }
        else{
            $session_id= $request->session;
            if($this->is_consultation_expired_by_session($session_id,$category->id)){
                abort(404);
            }
        }

        $products=Product::with('packs')->where('category_id',$category->id)->get();
        return view('Frontend.treatments')->with(['products'=>$products, 'product_id'=>$request->product_id, 'pack_id' => $request->pack_id]);
    }

    public function is_consultation_expired($user,$category){
        $latest_answer=Answer::where('user_id',$user)->where('category_id',$category)->latest()->first();
        if($latest_answer ==null){
            return true;
        }
        $date1 = new DateTime($latest_answer->created_at);
        $date2 = new DateTime();
        $interval = $date1->diff($date2);
        if($interval->days >= 6*30){
            return true;
        }
        else return false;
    }

    public function is_consultation_expired_by_session($session,$category){
        $latest_answer=Answer::where('user_id',$session)->where('category_id',$category)->latest()->first();
        
        if($latest_answer ==null){
            return true;
        }

        $date1 = new DateTime($latest_answer->created_at);
        $date2 = new DateTime();
        $interval = $date1->diff($date2);
        if($interval->days >= 1){
            return true;
        }
        else return false;
    }
}
