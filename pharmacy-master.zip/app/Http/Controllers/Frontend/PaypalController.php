<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

// Used to process plans
use PayPal\Api\ChargeModel;
use PayPal\Api\Currency;
use PayPal\Api\MerchantPreferences;
use PayPal\Api\PaymentDefinition;
use PayPal\Api\Plan;
use PayPal\Api\Patch;
use PayPal\Api\PatchRequest;
use PayPal\Common\PayPalModel;
use PayPal\Rest\ApiContext;
use PayPal\Auth\OAuthTokenCredential;
use Auth;

// use to process billing agreements
use PayPal\Api\Agreement;
use PayPal\Api\Payer;
use PayPal\Api\ShippingAddress;
use App\Subscription;
use App\Address;

use App\Mail\SubscriptionMail;
use Illuminate\Support\Facades\Mail;

class PaypalController extends Controller
{
    private $apiContext;
    private $mode;
    private $client_id;
    private $secret;
    private $plan_id;
    
    // Create a new instance with our paypal credentials
    public function __construct()
    {
        // Detect if we are running in live mode or sandbox
        if(config('paypal.settings.mode') == 'live'){
            $this->client_id = config('paypal.live_client_id');
            $this->secret = config('paypal.live_secret');
        } else {
            $this->client_id = config('paypal.sandbox_client_id');
            $this->secret = config('paypal.sandbox_secret');
        }
        // Set the Paypal API Context/Credentials
        $this->apiContext = new ApiContext(new OAuthTokenCredential($this->client_id, $this->secret));
        $this->apiContext->setConfig(config('paypal.settings'));
    }

    public function create_plan($price,$interval,$cycle=0){
        // Create a new billing plan
        $plan = new Plan();
        $plan->setName('App Name Monthly Billing')
          ->setDescription('Monthly Subscription to the App Name')
          ->setType('FIXED');
        
        // Set billing plan definitions
        $paymentDefinition = new PaymentDefinition();
        $paymentDefinition->setName('Regular Payments')
          ->setType('REGULAR')
          ->setFrequency('Week')
          ->setFrequencyInterval($interval)
          ->setCycles($cycle)
          ->setAmount(new Currency(array('value' => $price, 'currency' => 'GBP')));

        // Set merchant preferences
        $merchantPreferences = new MerchantPreferences();
        $merchantPreferences->setReturnUrl('https://promanhealth.co.uk/subscribe/paypal/return')
          ->setCancelUrl('https://promanhealth.co.uk/subscribe/paypal/return')
          ->setAutoBillAmount('yes')
          ->setInitialFailAmountAction('CONTINUE')
          ->setMaxFailAttempts('0');

        $plan->setPaymentDefinitions(array($paymentDefinition));
        $plan->setMerchantPreferences($merchantPreferences);
        
        //create the plan
        try {
            $createdPlan = $plan->create($this->apiContext);
        
            try {
                $patch = new Patch();
                $value = new PayPalModel('{"state":"ACTIVE"}');
                $patch->setOp('replace')
                  ->setPath('/')
                  ->setValue($value);
                $patchRequest = new PatchRequest();
                $patchRequest->addPatch($patch);
                $createdPlan->update($patchRequest, $this->apiContext);
                $plan = Plan::get($createdPlan->getId(), $this->apiContext);

                // Output plan id
                return $plan->getId();

            } catch (\PayPal\Exception\PayPalConnectionException $ex) {
                
                dd($ex->getData());
            } catch (\Exception $ex) {
                
                dd($ex->getData());
            }
            
        } catch (\PayPal\Exception\PayPalConnectionException $ex) {
            
            dd($ex->getData());
        } catch (\Exception $ex) {
            
            dd($ex->getMessage());
        }

    }

    public function paypalRedirect(Request $request){
        // Create new agreement
        $interval=$request->input('interval');
        $cycle=$request->input('duration');
        $subscription=Subscription::findOrFail($request->subscription);
        $subscription->shipping_value = $request->shipping_value;
        $subscription->save();

        // $address_1=$request->input('address_1');
        // $address_2=$request->input('address_2');
        // $country=$request->input('country');
        // $state=$request->input('state');
        // $zip=$request->input('zip');

        // $address=new Address();
        // $address->address_1=$address_1;
        // $address->address_2=$address_2;
        // $address->country=$country;
        // $address->state=$state;
        // $address->zip=$zip;
        
        // $address->save();

        // $subscription->update([
        //   'address_id'=>$address->id
        // ]);

        if($subscription->subscription_status_id != 7){
          abort(404);
        }

        $agreement = new Agreement();
        $agreement->setName('App Name Monthly Subscription Agreement')
          ->setDescription('Basic Subscription')
          ->setStartDate(\Carbon\Carbon::now()->addMinute(2)->toIso8601String());
       
        // Set plan id
        $plan = new Plan();
        $subscription->load(['pack']);
        
        $plan->setId($this->create_plan($subscription->pack->price,$interval,$cycle));
        $agreement->setPlan($plan);

        // Add payer type
        $payer = new Payer();
        $payer->setPaymentMethod('paypal');
        $agreement->setPayer($payer);

        try {
          // Create agreement
          $agreement = $agreement->create($this->apiContext);
           
          // Extract approval URL to redirect user
          $approvalUrl = $agreement->getApprovalLink();
          $paypal_token=$this->linkToToken($approvalUrl);
        
          $subscription->update(['paypal_token'=>$paypal_token]);

          return redirect($approvalUrl);
        } catch (\PayPal\Exception\PayPalConnectionException $ex) {
          dd($ex->getData()); 
          return redirect()->route('payment.failed');
        } catch (\Exception $ex) {
          dd($ex->getMessage());
          return redirect()->route('payment.failed');
        }

    }

    public function paypalReturn(Request $request){

        $token = $request->token;
        $subscription=Subscription::where('paypal_token',$token)->firstOrFail();
        $agreement = new \PayPal\Api\Agreement();

        try {
            // Execute agreement
            $result = $agreement->execute($token, $this->apiContext);
            $subscription->update(
              [
                'agreement_id'=>$agreement->id,
                'subscription_status_id'=>3
              ]
            );
            return redirect()->route('payment.success');
        } catch (\PayPal\Exception\PayPalConnectionException $ex) {
          return redirect()->route('payment.failed');
        }
    }

      public function checkout(Request $request,Subscription $subscription){
      $subscription=Subscription::findOrFail($subscription->id);
      if($subscription->subscription_status_id != 7){
        abort(404);
      }       

      return view('Frontend.checkout')->with(['subscription'=>$subscription]);
    }

    public function failed_payment(){
      return view('Frontend.failed_payment');
    }

    public function success_payment(){
      return view('Frontend.success_payment');
    }

    public function linkToToken($link){
      $indexStartsWithEC = strpos($link, "EC-");
      $linkStartsWithEC =  substr($link, $indexStartsWithEC);
      $endsPosOfAnd = strpos($linkStartsWithEC, "&");
      return substr($linkStartsWithEC, 0);
    }

}