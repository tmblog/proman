<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Category;
use Datetime;
use App\Answer;
use App\Product;

class CategoryController extends Controller
{
    protected $category;

    public function __construct(Category $category){
        $this->category=$category;
    }

    public function show(){
        $categories=$this->category->get()->toArray();
        return view('Frontend.category')->with(['categories'=>$categories]);
    }

    public function showCategory(Category $category){
        return view('Frontend.categoryDetails')->with(['category'=>$category]);
    }

    
    public function showProduct(Category $category,Product $product)
    {
        return view('Frontend.productDetails')->with(['product'=>$product->load('packs.strength'), 'category'=>$category]);
    }
    
    public function questionnaire(Category $category, Request $request){
        if(\Auth::check()){
            $user_id=auth()->user()->id;
            if(!($this->is_consultation_expired($user_id,$category->id))){
                return redirect('/treatments/'.$category->slug.'/treatments?product='.$request->product.'&pack='.$request->pack);
            }
        }
        return view('Frontend.questionnaire')->with(['category'=>$category, 'product_id' => $request->product, 'pack_id' => $request->pack]);
    }

    public function is_consultation_expired($user,$category){
        $latest_answer=Answer::where('user_id',$user)->where('category_id',$category)->latest()->first();
        if($latest_answer ==null){
            return true;
        }
        $date1 = new DateTime($latest_answer->created_at);
        $date2 = new DateTime();
        $interval = $date1->diff($date2);
        if($interval->days >= 6*30){
            return true;
        }
        else return false;
    }
}
