<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Category;
use App\Product;
use App\Answer;
use App\Subscription;
use App\Order;
use App\Pack;

class AnswerController extends Controller
{
    protected $answer;

    public function __construct(Answer $answer){
        $this->answer=$answer;
    }
    public function store(Category $category,Request $request){
        if(\Auth::check()){
            $user_id=auth()->user()->id;
        }
        else{
            $user_id=\Session::getId();
        }

        $questions=json_decode($category->questions);

        $answers=$request->data;

        foreach($answers as $key=>$answer){
            foreach($questions->pages as $page){
                foreach($page->elements as $element){
                    if($element->name == $key){
                        $question_text="";
                        $answer_text=$answer;
                        if($element->type == "html"){
                            $question_text=$element->html;
                        }
                        else{
                            $question_text=$element->title;
                        }

                        $new=new Answer();

                        if(gettype($answer_text) == "array"){
                            $c = 0;
                            $str = "";
                            $risks = [];
                            foreach ($answer_text as $ans) {
                                if($c != 0){
                                    $str .= ",";
                                }
                                $str .= substr($ans, 1);
                                array_push($risks, $ans[0]);
                                $c++;
                            }
                            $new->ans = $str;
                            $new->risk = $this->calculate_risks($risks);
                        }else{
                            if(gettype($answer_text) == "integer"){
                                $answer_text = strval($answer_text);
                            }
                            $new->ans = substr($answer_text, 1);
                            $new->risk = $answer_text[0];
                        }
                        $new->question=$question_text;
                        $new->user_id=$user_id;
                        $new->category_id=$category->id;
                        $new->save();
                    }
                }
            }
        }
        
        return response()->json('/treatments/'.$category->slug.'/treatments?session='.$user_id.'&product_id='.$request->product_id.'&pack_id='.$request->pack_id);
    }

    public function calculate_risks($arr)
    {
        return max($arr);
    }

    public function is_consultation_expired($user,$category){
        $latest_answer=Answer::where('user_id',$user)->where('category_id',$category)->latest()->first();
        if($latest_answer ==null){
            return true;
        }
        $date1 = new DateTime($latest_answer->created_at);
        $date2 = new DateTime();
        $interval = $date1->diff($date2);
        if($interval->days >= 6*30){
            return true;
        }
        else return false;
    }
}
