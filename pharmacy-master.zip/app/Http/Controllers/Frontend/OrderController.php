<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Order;
use App\OrderStatus;
class OrderController extends Controller
{
    protected $order;

    public function index(){
        $orders=Order::latest()->paginate(15);
        return view('Backend.Pharmacy.orders')->with(['orders'=>$orders]);
    }

    public function show(Order $order){
        $statuses=OrderStatus::all()->collect()->filter(function ($value, $key) {
            return $value->id >2;
        });

        $subscription = $order->subscription;
        $cat = $subscription->product->category;
        $answers= \App\Answer::where('category_id', $cat->id)->where('user_id', $subscription->patient->user->id)->get();

        $order->load(['subscription.address', 'pack']);
        return view('Backend.Pharmacy.order_details')->with(
            ['order'=>$order,'statuses'=>$statuses, 'subscription'=> $subscription,
        'answers'=>$answers]);
    }

    public function order_confirmation(Request $request){
        $this->validate($request, [
            'order_status' => 'required|not_in:0,1,2',
            'order'=>'required'
        ]);
        $status=$request->input('order_status');
        $get_order=$request->input('order');
        $order=Order::findOrFail($get_order);
        $order->update(['order_status_id'=>$status]);
        return redirect()->route('order-index')->with('success',"Successfully changed the order's status");
    }
}
