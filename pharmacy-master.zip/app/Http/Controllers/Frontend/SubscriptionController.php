<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Subscription;
use App\Patient;
use App\Order;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Laravel\Jetstream\Jetstream;

class SubscriptionController extends Controller 
{
    protected $subscription;

    public function __construct(Subscription $subscription){
        $this->subscription=$subscription;
    }

    public function index(){
        $subscriptions=$this->subscription->orderBy('updated_at','DESC')->paginate(15);
        return view('Backend.subscriptions')->with(['subscriptions'=>$subscriptions]);
    }

    public function show(Subscription $subscription){
        $cat = $subscription->product->category;
        
        $answers= \App\Answer::where('category_id', $cat->id)->where('user_id', $subscription->patient->user->id)->get();
        $histories=Subscription::where('patient_id',$subscription->patient_id)->where('id','!=',$subscription->id)->orderBy('updated_at','DESC')->get();
        return view('Backend.Patient.history')->with(['subscription'=>$subscription->load('address'),'answers'=>$answers,'histories'=>$histories]);
    }

    public function approve(Subscription $subscription){
        $subscription->approved_by = \Auth::user()->name;
        $subscription->save();
        return view('Backend.Doctor.approve')->with(['subscription'=>$subscription]);
    }

    public function post_approve(Request $request,Subscription $subscription){
        $inputs=$request->all();

        
        if($subscription->is_edited ==1){
            $duration=$inputs['edited_duration'];
        }
        else{
            $duration=$inputs['duration'];
        }

        $subscription->update([
            'subscription_status_id'=>1,
            'duration'=>$duration,
            'edited_duration'=>null,
            'is_edited'=>0,
            'notes_for_customer'=>$inputs['notes_for_customer'],
            'pending_reactivation'=>2,
        ]);

        $order=new Order();
        $order->patient_id=$subscription->patient_id;
        $order->product_id=$subscription->product_id;
        $order->pack_id=$subscription->pack_id;
        $order->notes_for_pharmacy=$inputs['notes_for_pharmacy'];
        $order->order_status_id=5;
        $order->subscription_id = $subscription->id;
        $order->save();
        
        return redirect()->route('subscriptions-index')->with('success','You have approved the subscription request and it is placed to the order list');
    }

    public function reject(Subscription $subscription){
        return view('Backend.Doctor.reject')->with(['subscription'=>$subscription]);
    }

    public function post_reject(Request $request,Subscription $subscription){
        $inputs=$request->all();
       
        if($subscription->subscription_status_id ==6){
            $subscription->update([
                'subscription_status_id'=>$subscription->previous_status,
                'notes_for_customer'=>$inputs['notes_for_customer'],
                'pending_reactivation'=>2,
                'is_edited'=>0,
                'edited_duration'=>null
            ]);
        }
        else{
            $subscription->update([
                'subscription_status_id'=>2,
                'notes_for_customer'=>$inputs['notes_for_customer'],
                'pending_reactivation'=>2,
            ]);
        }
        return redirect()->route('subscriptions-index')->with('success','You have rejected the subscription request');
    }

    public function store(Request $request){

        if(!(\Auth::check())){

            $validated = $request->validate([
                'email' => 'required|string|email|max:255|unique:users',
            ]);

            
            $user=new User();
            if($request->name){
                $user->name=$request->name;
            }else{
                $user->name=$request->firstname . ' ' . $request->lastname;
            }
            
            $user->email=$request->email;
            $user->password=Hash::make($request->password);
            $user->role_id=2;
            $user->save();

            $patient= new Patient();
            $patient->user_id=$user->id;
            $patient->age=$request->age;
            $patient->city = $request->city;
            $patient->postcode = $request->postcode;
            $patient->terms = $request->terms;
            $patient->offer = $request->offer;
            $patient->phone = $request->phone;
            $patient->gender = $request->gender;
            $patient->dob = $request->dob;
            $patient->patient_id = $request->patient_id;
            $patient->save();

            $subscription=new Subscription();
            $subscription->patient_id=$patient->id;
            $subscription->product_id=$request->product_id;
            $subscription->pack_id=$request->pack_id;
            $subscription->subscription_status_id=7;
            $subscription->save();

            $answers = \App\Answer::where('user_id', \Session::getId())->get();

            foreach ($answers as $ans) {
                $ans->user_id = $user->id;
                $ans->save();
            }

            $address_1=$request->input('address_1');
        

            $address=new \App\Address();
            $address->address_1=$address_1;
        
        
            $address->save();

            $subscription->update([
                'address_id'=>$address->id
            ]);

            return redirect()->route('patient.checkout',$subscription);
            
        }
        else{

            $subscription=new Subscription();
            $subscription->patient_id=\Auth::user()->patient->id;
            $subscription->product_id=$request->product_id;
            $subscription->pack_id=$request->pack_id;
            $subscription->subscription_status_id=7;
            $subscription->save();
            return redirect()->route('patient.checkout',$subscription);
        }

    }
}
