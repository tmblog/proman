<?php

namespace App\Http\View\Composer;

use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use App\Category;

class CategoryComposer{

    public function compose(View $view)
    {
        $all_categories=Category::latest()->get();
        $view->with('all_categories',$all_categories);
    }
}
