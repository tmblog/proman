<?php

namespace App\Http\Responses;

use Illuminate\Support\Facades\Auth;
use Laravel\Fortify\Contracts\LoginResponse as LoginResponseContract;

class LoginResponse implements LoginResponseContract
{

    public function toResponse($request)
    {
        if(Auth::check()){
            if(Auth::user()->role_id ===4){
                return redirect(route('doctor-dashboard'));
            }
            else if(Auth::user()->role_id ===2){
                return redirect(route('patient-dashboard'));
            }

            else if(Auth::user()->role_id ===3){
                return redirect(route('pharmacist-dashboard'));
            }
        }
    }

}