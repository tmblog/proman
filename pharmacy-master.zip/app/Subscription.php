<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Subscription extends Model
{
    protected $fillable=['risk_level','patient_id','product_id','duration','interval',
    'pack_id','subscription_status_id','payment_id','zendex_link','notes_for_customer','risk_value','remaining',
    'is_edited','notes_for_doctor_edit','notes_for_doctor_pause','notes_for_doctor_reactivate','pending_reactivation','edited_duration',
    'previous_status','agreement_id','paypal_token','address_id'
];
    
    public function answers(){
        return $this->hasMany('App\Answer');
    }

    public function patient(){
        return $this->belongsTo('App\Patient');
    }

    public function product(){
        return $this->belongsTo('App\Product');
    }

    public function subscription_status(){
        return $this->belongsTo('App\SubscriptionStatus');
    }

    public function pack(){
        return $this->belongsTo('App\Pack');
    }

    public function address(){
        return $this->belongsTo('App\Address');
    }

    // public function order_status(){
    //     return $this->belongsTo('App\OrderStatus');
    // }
}
