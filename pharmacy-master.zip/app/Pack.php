<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Pack extends Model
{
    public function products(){
        return $this->belongsToMany('App\Product','product_pack');
    }

    public function strength(){
        return $this->belongsTo('App\Strength');
    }
}
