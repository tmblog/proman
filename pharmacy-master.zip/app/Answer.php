<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Answer extends Model
{
    protected $table='answers';

    public function options(){
        return $this->belongsToMany('App\Option','answer_option');
    }

    public function question(){
        return $this->belongsTo('App\Question');
    }
}
