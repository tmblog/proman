<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Order extends Model
{
    protected $table="orders";

    protected $fillable=['order_status_id'];

    public function patient(){
        return $this->belongsTo('App\Patient');
    }

    public function product(){
        return $this->belongsTo('App\Product');
    }

    public function order_status(){
        return $this->belongsTo('App\OrderStatus');
    }

    public function pack(){
        return $this->belongsTo('App\Pack');
    }

    public function subscription(){
        return $this->belongsTo('App\Subscription');
    }
}
