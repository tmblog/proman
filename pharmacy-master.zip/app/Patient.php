<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Patient extends Model
{
    protected $table="patients";
 
    protected $fillable=['age','ni_number','user_id'];

    public function user(){
        return $this->belongsTo('App\Models\User');
    }

    public function subscriptions(){
        return $this->hasMany('App\Subscription');
    }
    
}
