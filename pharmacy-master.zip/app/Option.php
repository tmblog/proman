<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Option extends Model
{
    protected $table="options";

    public function questions(){
        return $this->belongsToMany('App\Question');
    }

    public function safes(){
        return $this->belongsToMany('App\Question','safe_options');
    }

    public function risks(){
        return $this->belongsToMany('App\Question','risky_options');
    }

    public function moderates(){
        return $this->belongsToMany('App\Question','moderate_options');
    }

    public function is_safe($question_id){
        $questions_where_the_option_is_safe=$this->safes;
        foreach($questions_where_the_option_is_safe as $q){
            if($q->id ==$question_id)
            return true;
        }
        return false;
    }

    public function is_risky($question_id){
        $questions_where_the_option_is_risky=$this->risks;
        foreach($questions_where_the_option_is_risky as $q){
            if($q->id ==$question_id)
            return true;
        }
        return false;
    }

    public function is_moderate($question_id){
        $questions_where_the_option_is_moderate=$this->moderates;
        foreach($questions_where_the_option_is_moderate as $q){
            if($q->id ==$question_id)
            return true;
        }
        return false;
    }
}
