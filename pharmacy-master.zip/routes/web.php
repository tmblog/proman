<?php

use App\Subscription;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

//doctor's routes
Route::group(['prefix'=>'/prescribers','middleware' => 'doctor'], function(){
    Route::get('/dashboard','Frontend\DoctorController@dashboard')->name('doctor-dashboard');
    Route::get('/subscriptions','Frontend\SubscriptionController@index')->name('subscriptions-index');
    Route::get('/subscriptions/{subscription}','Frontend\SubscriptionController@show')->name('subscription-show');
    
    Route::get('/subscriptions/{subscription}/approve','Frontend\SubscriptionController@approve')->name('subscription-approve');
    Route::post('/subscriptions/{subscription}/approve','Frontend\SubscriptionController@post_approve')->name('subscription-post-approve');

    Route::get('/subscriptions/{subscription}/reject','Frontend\SubscriptionController@reject')->name('subscription-reject');
    Route::post('/subscriptions/{subscription}/reject','Frontend\SubscriptionController@post_reject')->name('subscription-post-reject');
});

//patient's/authenticated user's routes
Route::group(['prefix'=>'/patient','middleware' => 'patient'], function(){
    Route::get('/dashboard','Frontend\PatientController@dashboard')->name('patient-dashboard');
    Route::get('/subscription','Frontend\PatientController@index')->name('subscription-patient');
    Route::get('/category/{category}/{product}/{pack}/question','Frontend\ProductController@product_questions')->name('product-questions');

    Route::get('/subscription/{subscription}/edit','Frontend\PatientController@edit')->name('subscription-patient-edit');
    Route::post('/subscription/{subscription}/edit','Frontend\PatientController@update')->name('subscription-patient-update');

    Route::post('/subscription/{subscription}/cancel','Frontend\PatientController@post_cancel')->name('subscription-patient-post-cancel');

    Route::get('/subscription/{subscription}/pause','Frontend\PatientController@pause')->name('subscription-patient-pause');
    Route::post('/subscription/{subscription}/pause','Frontend\PatientController@post_pause')->name('subscription-patient-post-pause');

    Route::get('/subscription/{subscription}/reactivate','Frontend\PatientController@reactivate')->name('subscription-patient-reactivate');
    Route::post('/subscription/{subscription}/reactivate','Frontend\PatientController@post_reactivate')->name('subscription-patient-post-reactivate');
});

//pharmacist's routes
Route::group(['prefix'=>'/pharmacy','middleware' => 'pharmacist'], function(){
    Route::get('/dashboard','Frontend\PharmacistController@dashboard')->name('pharmacist-dashboard');
    Route::get('/orders','Frontend\OrderController@index')->name('order-index');
    Route::get('/orders/{order}','Frontend\OrderController@show')->name('order-show');
    Route::post('/order-deliver-confirmation','Frontend\OrderController@order_confirmation')->name('order-confirm');
});

//un-authenticated user's routes
Route::get('/payment-failed','Frontend\PaypalController@failed_payment')->name('payment.failed');
Route::get('/payment-success','Frontend\PaypalController@success_payment')->name('payment.success');

Route::get('/treatments','Frontend\CategoryController@show')->name('category-index');
Route::get('/treatments/{category}','Frontend\CategoryController@showCategory')->name('category-details');
Route::get('/treatments/{category}/consultation','Frontend\CategoryController@questionnaire')->name('product-questionnaire');
Route::get('/treatments/{category}/treatments','Frontend\ProductController@treatment')->name('category-treatment');
Route::get('/treatments/{category}/{product}','Frontend\CategoryController@showProduct')->name('product-details');
Route::post('/submit-treatment','Frontend\SubscriptionController@store')->name('subscription-store');
Route::post('/answer/{category}','Frontend\AnswerController@store')->name('store-answer');
Route::get('/checkout/{subscription}','Frontend\PaypalController@checkout')->name('patient.checkout');
    
Route::get('/prescription/{subscription}', function(Subscription $subscription){
    return view('prescription')->with(['subscription' => $subscription]);
});

Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});


Route::get('/test',function(Request $req){
    return response(['data'=>$req]);
});

Route::get('/',function(){
    return view('welcome');
});

Route::get('ed-consultation', function(){
    return view('ed-consultation');
});

Route::get('erectile-dysfunction-treatments', function(){
    return view('erectile-dysfunction-treatments');
});

Route::get('all-medical-treatments', function(){
    return view('all-medical-treatments');
});

Route::get('travel-health', function(){
    return view('travel-health');
});

Route::get('mens-health', function(){
    return view('mens-health');
});

Route::get('general-health', function(){
    return view('general-health');
});

Route::get('womens-health', function(){
    return view('womens-health');
});

Route::get('faq', function(){
    return view('faq');
});

Route::get('contactus', function(){
    return view('contactus');
});

Route::get('/clear-cache', function() {
    Artisan::call('view:clear');
    return "Cache is cleared";
});

use App\Mail\TestMail;
use Illuminate\Support\Facades\Mail;
use Laravel\Jetstream\Rules\Role;
use Mailgun\Mailgun;

Route::post('contactus', function(Request $request){


# Instantiate the client.
$mgClient = Mailgun::create('3b02dfe45e6fc6fd8e783269b7204bd4-c485922e-15e9ee5e');
$domain = "sandbox8119d49cd2784bc892ddceea7818b1d5.mailgun.org";

# Make the call to the client.
$result = $mgClient->messages()->send("$domain",
	array('from'    => 'Proman Health <postmaster@sandbox8119d49cd2784bc892ddceea7818b1d5.mailgun.org>',
		  'to'      => 'MIR SABBIR ALAM <mirsabbiralam@gmail.com>',
		  'subject' => 'Contact request',
		  'text'    => $request->message. ' '. $request->email));

// You can see a record of this email in your logs: https://app.mailgun.com/app/logs.

// You can send up to 300 emails/day from this sandbox server.
// Next, you should add your own domain so you can send 10000 emails/month for free.
    Session::flash('status', 'email sent successfully');
    return redirect('/contactus');
});


Route::get('/send-mail',function(){
    $data=['name'=>'Sabbir'];
    Mail::to('zoanmahbub@gmail.com')->send(new TestMail($data));
    return 'Email sent Successfully';
});

Route::get('create_paypal_plan', 'Frontend\PaypalController@create_plan');
Route::post('/subscribe/paypal', 'Frontend\PaypalController@paypalRedirect')->name('paypal.redirect');
Route::get('/subscribe/paypal/return', 'Frontend\PaypalController@paypalReturn')->name('paypal.return');

Route::get('{page}', function(\App\Page $page){
    return view('page-template')->with(['page' => $page]);
});

Route::post('/add-ticket/{subscription}', function(Request $request, \App\Subscription $subscription){
    
    $subscription->zendex_link = "https://proman.uvdesk.com/en/member/ticket/view/". $request->ticket;
    $subscription->save();
    return redirect()->back();
});
