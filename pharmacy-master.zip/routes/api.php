<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



use \PayPal\Api\VerifyWebhookSignature;
use \PayPal\Api\WebhookEvent;
use PayPal\Rest\ApiContext;
use PayPal\Auth\OAuthTokenCredential;

Route::post('/paypal-webhook', function (Request $request) {


    if (config('paypal.settings.mode') == 'live') {
        $client_id = config('paypal.live_client_id');
        $secret = config('paypal.live_secret');
    } else {
        $client_id = config('paypal.sandbox_client_id');
        $secret = config('paypal.sandbox_secret');
    }

    // Set the Paypal API Context/Credentials
    $apiContext = new ApiContext(new OAuthTokenCredential($client_id, $secret));
    $apiContext->setConfig(config('paypal.settings'));


    /** @var String $requestBody */
    $requestBody = $request->getContent();
    /**
     * Receive the entire body that you received from PayPal webhook.
     * Just uncomment the below line to read the data from actual request.
     */
    /** @var String $bodyReceived */
    // $bodyReceived = file_get_contents('php://input');

    $headers = $request->header();

    /**
     * Receive HTTP headers that you received from PayPal webhook.
     * Just uncomment the below line to read the data from actual request.
     */
    /** @var Array $headers */
    //$headers = getallheaders();

    /**
     * In documentations https://developer.paypal.com/docs/api/webhooks/v1/#verify-webhook-signature
     * All header keys as UPPERCASE, but I receive the header key as the example array, First letter as UPPERCASE
     */

    $headers = array_change_key_case($headers, CASE_UPPER);

    $signatureVerification = new VerifyWebhookSignature();
    $signatureVerification->setAuthAlgo($headers['PAYPAL-AUTH-ALGO'][0]);
    $signatureVerification->setTransmissionId($headers['PAYPAL-TRANSMISSION-ID'][0]);
    $signatureVerification->setCertUrl($headers['PAYPAL-CERT-URL'][0]);
    $signatureVerification->setWebhookId("22C2685889441404U"); // Note that the Webhook ID must be a currently valid Webhook that you created with your client ID/secret.
    $signatureVerification->setTransmissionSig($headers['PAYPAL-TRANSMISSION-SIG'][0]);
    $signatureVerification->setTransmissionTime($headers['PAYPAL-TRANSMISSION-TIME'][0]);

    $signatureVerification->setRequestBody($requestBody);
    $request2 = clone $signatureVerification;


    try {
        /** @var \PayPal\Api\VerifyWebhookSignatureResponse $output */

        $output = $signatureVerification->post($apiContext);

        if ($output->getVerificationStatus() == "FAILURE") return;


        $body = json_decode($request2->getRequestBody());

        if ($body->event_type == "BILLING.SUBSCRIPTION.PAYMENT.FAILED") {
            $agreement_id = $body->resource->id;
            $subscription = \App\Subscription::where('aggrement_id', $agreement_id)->firstOrFail();
            $subscription->subscription_status_id = 8; // payment failed
            $subscription->save();
        }

        if ($body->event_type == "BILLING.SUBSCRIPTION.CANCELLED") {
            $agreement_id = $body->resource->id;
            $subscription = \App\Subscription::where('aggrement_id', $agreement_id)->firstOrFail();
            $subscription->subscription_status_id = 9; // subscription cancled
            $subscription->save();
        }

        if ($body->event_type == "BILLING.SUBSCRIPTION.EXPIRED") {
            $agreement_id = $body->resource->id;
            $subscription = \App\Subscription::where('aggrement_id', $agreement_id)->firstOrFail();
            $subscription->subscription_status_id = 8; // payment failed
            $subscription->save();
        }
    } catch (\Exception $ex) {
        // NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY

    }

    // NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
    // ResultPrinter::printResult("Validate Received Webhook Event", "WebhookEvent", $output->getVerificationStatus(), $request->toJSON(), $output);

});



use App\Address;
use PayPalCheckoutSdk\Core\PayPalHttpClient;
use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersCaptureRequest;

Route::post('/paypal-create-payment', function (Request $request) {

    //our validation
    $subscription = \App\Subscription::findOrFail($request->subscription_id);
    $address_1=$request->address_1;
    $address_2=$request->address_2;
    $country=$request->country;
    $state=$request->state;
    $zip=$request->zip;

    $address=new Address();
    $address->address_1=$address_1;
    $address->address_2=$address_2;
    $address->country=$country;
    $address->state=$state;
    $address->zip=$zip;
    $address->save();

    $subscription->update([
      'address_id'=>$address->id,
      'duration'=>1
    ]);

    // Creating an environment
    $clientId = config('paypal.sandbox_client_id');
    $clientSecret = config('paypal.sandbox_secret');

    $environment = new SandboxEnvironment($clientId, $clientSecret);
    $client = new PayPalHttpClient($environment);

    $request = new OrdersCreateRequest();
    $request->prefer('return=representation');
    $request->body = [
        "intent" => "CAPTURE",
        "purchase_units" => [[
            "amount" => [
                "value" => number_format($subscription->pack->price, 2),
                "currency_code" => "GBP"
            ]
        ]],
        "application_context" => [
            "cancel_url" => "https://example.com/cancel",
            "return_url" => "https://example.com/return"
        ]
    ];

    try {
        // Call API with your client and get a response for your call
        $response = $client->execute($request);


        $orderId = $response->result->id;
        $subscription->paypal_order_id = $orderId;
        $subscription->save();

        // If call returns body in response, you can get the deserialized version from the result attribute of the response
        return response()->json($response->result, 200);
    } catch (HttpException $ex) {
        echo $ex->statusCode;
        print_r($ex->getMessage());
    }
});


Route::post('/paypal-execute-payment', function (Request $req) {
    
    $clientId = config('paypal.sandbox_client_id');
    $clientSecret = config('paypal.sandbox_secret');

    $environment = new SandboxEnvironment($clientId, $clientSecret);
    $client = new PayPalHttpClient($environment);
    // Here, OrdersCaptureRequest() creates a POST request to /v2/checkout/orders
    // $response->result->id gives the orderId of the order created above
    $request = new OrdersCaptureRequest($req->orderID);
    $request->prefer('return=representation');
    try {
        // Call API with your client and get a response for your call
        
        $response = $client->execute($request);

        //make payment complete of oneoff
        $subscription = \App\Subscription::where('paypal_order_id', $req->orderID)->firstOrFail();
        $subscription->subscription_status_id = 3;
        $subscription->save();

        print_r($response);
    } catch (\Exception $ex) {
        abort(400);
    }
});
