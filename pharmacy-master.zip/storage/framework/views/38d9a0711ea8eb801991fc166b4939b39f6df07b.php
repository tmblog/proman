
<script> window.baseUrl = '<?php echo e(url('/')); ?>';</script>
<script> window.storageUrl = '<?php echo e(env('STORAGE_URL')); ?>';</script>
<script> window.publicUrl = '<?php echo e(env('PUBLIC_PATH')); ?>';</script>
<script> window.token = '<?php echo e(@csrf_token()); ?>';</script>
<script> window.id = '';</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/js/plugins.min.js" type="text/javascript"></script>
<script src="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/js/components/datepicker.js" type="text/javascript"></script>

<!-- Footer Scripts
============================================= -->
<script src="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/js/functions.js"></script>
<?php /**PATH /home/proman/public_html/pharmacy-master/resources/views/Frontend/Master/footer_links.blade.php ENDPATH**/ ?>