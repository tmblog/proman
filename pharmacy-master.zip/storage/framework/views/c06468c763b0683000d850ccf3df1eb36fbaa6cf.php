<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php echo $__env->make('Frontend.Master.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<meta name="description" content="ProMan Health customer frequency asked questions about Online men's health and pharmacy. ProMan health provides competitive prices on medication and men's health online."/>

<!-- Document Title
============================================= -->
<title>ProMan Health FAQ | Competitive Prices on ED Treatment</title>
</head>
<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<?php echo $__env->make('Frontend.Master.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- #header end -->



		<!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">
					<div class="heading-block border-bottom-0 bottommargin-sm">
						<h1 class="nott ls0">FAQs</h1>
					</div>
					<div class="row col-mb-50 mb-0">
						 
						  <div class="grid-filter-wrap">
								<ul class="grid-filter style-4 customjs">

									<li class="activeFilter mb-0"><a href="#" data-filter="all">All</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-work">How does it work?</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-order">Why ProMan Health?</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-delivery">Delivery</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-clinic">Clinical</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-privacy">Privacy</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-account">Account</a></li>
									<li class="mb-0"><a href="#" data-filter=".faq-billing">Billing/Refunds</a></li>

								</ul>
							</div>

							<div class="clear"></div>

							<div id="faqs" class="faqs">

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Is this a subscription service?
										</div>
									</div>
									<div class="toggle-content">We offer our patients the option to either make a one time purchase or to sign up as a subscription service. The nature of the treatments we provide are ongoing and therefore it makes sense to provide a repeat service. You will have a repeat prescription which will save you the time of having to re-order every month with us. Your repeat prescriptions would be approved by one of our qualified Pharmacist Prescribers similar to the repeat prescription service provided at  your local GP.<br>
									If you do opt for a subscription we will be able to offer the medication at a lower price to a single purchase customer. You will have the option to pause or cancel your monthly/bimonthly repeat in your patient account.<br>
									We will not automatically put you onto a repeat prescription service unless specifically requested.</div>
								</div>

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Can I sign up for a trial?
										</div>
									</div>
									<div class="toggle-content">We do not offer a free trial. For ED treatment there are two common treatments; you may wish to purchase a small pack size of each type at a time to find out which treatment is most suitable for you (assuming both are clinically appropriate for you). Note: You cannot use more than one ED treatment at the same time.</div>
								</div>

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											What if a treatment isn’t working for me?
										</div>
									</div>
									<div class="toggle-content">There are multiple treatment options available for the same condition. Some treatments will be more effective than others depending on each individual. This is not unusual and can happen to anyone. Please get in touch with our Proman Clinical Team and we can explain the options available. You can try small quantities of each treatment until the most suitable option is found for you.</div>
								</div>

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Why do I need a prescription?
										</div>
									</div>
									<div class="toggle-content">Most medications in the UK require a prescription from a healthcare professional (doctor or pharmacist prescriber) before it can be dispensed to the patient by a pharmacy. The prescription will not be issued by the healthcare practitioner until an online medical consultation is completed by the patient. This process is legally required in the UK and is in place to ensure you receive the appropriate treatment for your condition and most importantly to ensure it is safe and effective for the patient.<br>All of the treatments we provide including Sildenafil/Viagra are prescription only medications. Therefore, you must complete our medical questionnaire (consultation) before we can prescribe the appropriate medication for your condition.
									</div>
								</div>

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How do I make an order?
										</div>
									</div>
									<div class="toggle-content">Click on treatments which will show you what conditions we provide treatment for. Once you go into the treatment page we will ask you to complete a medical questionnaire which will usually  take between 3-5 minutes. This will help our Proman Clinical Team to assess the suitability and safety of the treatment for your condition taking into account your medical and medication history.<br>
									You will be given the option to choose the medication, where there are more than one treatment available. You will then have the option to select the strength and quantity that you will like to order. Your request will then be reviewed by our Clinical Team to ensure the treatment is safe and effective for your condition.<br>
									Payment details will be taken and once the order is confirmed payment will be processed. If a treatment is not deemed suitable by our Clinical Team, resulting in rejecting the prescription request, then a refund will be given for the treatment.
									</div>
								</div>

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Can my partner order for me?
										</div>
									</div>
									<div class="toggle-content">No. The prescription request must be made by the person intending to take the medication. Before a prescription can be approved we must directly receive the medical history of the patient intending to use the medication.</div>
								</div>

								<div class="toggle faq faq-work">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Are you licensed to be providing prescription medicine?
										</div>
									</div>
									<div class="toggle-content">All of our clinicians are UK qualified and fully regulated and licensed to undertake clinical work in the UK. They are also based in the UK and have extensive experience working in the NHS. Please visit the ‘About us’ section of our website to learn more about the company, founder and the clinical team.<br> 
									We are regulated by the Care Quality Commission (CQC). Our partner pharmacy (Medichem Pharmacy) is regulated by the General Pharmaceutical Council (GPhC) and the Medicines and Healthcare Regulatory Authority (MHRA). Lastly, all our Pharmacists Prescribers are regulated by the General Pharmaceutical Council (GPhC) and are fully insured to undertake the prescribing activities. You can verify the registrations of all our clinicians by All registration details can be verified by visiting the regulatory body websites. Link is available in the ‘About us’ section.
									</div>
								</div>

								<div class="toggle faq faq-order">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Why order online as opposed to go to my GP or local pharmacy?
										</div>
									</div>
									<div class="toggle-content">Patient choice is paramount. You should have the freedom to choose where you get your medications and treatment from. This could be from your local pharmacy, GP or from a reputable online pharmacy.<br> 
									We would recommend you consider purchasing your medications online for the following reasons:
									<ul>
										<li>Fast and convenient - no appointments are needed and you can complete a medical questionnaire 24 hours a day to access our treatments.</li>
										<li>The online approach is discreet and confidential without you having to turn up for an appointment in person or talking to a pharmacist in front of other customers. The preferred form of communication is via email.</li>
										<li>Treatment for Erectile Dysfunction, Premature Ejaculation and Hair Loss are not usually available on the NHS. Your GP will usually prescribe the medication on a private prescription which will cost you a lot more than what you will pay online.</li>
										<li>Your GP is usually restricted by NHS guidelines on how many tablets they can prescribe at a time. This is usually 4-8 tablets per month for the treatment of ED, and therefore is not usually enough for many men.</li>
									</ul>
									</div>
								</div>

								<div class="toggle faq faq-order">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How can we help?
										</div>
									</div>
									<div class="toggle-content">The Proman Clinical Team will be able to approve your prescription within 24 hours (usually within a few hours)  of you filling in our online medical questionnaire. If you have a more complicated health background that requires further information, they will contact you (via email or phone) to ascertain the relevant medical history to ensure safe and effective treatment provision.<br> 
									Once the consultation is complete and the medication is deemed appropriate and safe, the electronic prescription will be sent to our Partner Pharmacy, where the staff will process your order and post your medication out to your chosen address via Royal Mail.<br> 
									We are considerably cheaper than any high street pharmacy and we use discreet packaging i.e. plain envelopes, that do not in any way give any details of what the parcel contains.
									</div>
								</div>

								<div class="toggle faq faq-order">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Why are you cheaper than high street pharmacies?
										</div>
									</div>
									<div class="toggle-content">We are able to offer the same medications as high street pharmacy chains because we purchase the same UK licensed medications from the same suppliers . The only difference is that we are able to keep our costs down by not having expensive high street stores and by focusing on a small limited number of treatments</div>
								</div>

								<div class="toggle faq faq-delivery">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How will my medication be delivered?
										</div>
									</div>
									<div class="toggle-content">All our medication will be packaged discreetly by our partner pharmacy, and then delivered by Royal Mail to your chosen address. Your delivery will be posted through the letterbox where possible and will not require a signature. We therefore, advise you to be very careful if children or pets can access the medications delivered to you.<br>
									We can deliver to any UK address including your home, workplace or neighbour. Depending on quantity and size of packaging we will always endeavour to send it in packaging that will fit through a standard letter box.<br> 

									When the package is too large to go through a letterbox you can advise us of a safe place at your designated delivery address to leave the package unless deemed inappropriate or unsafe by Royal Mail delivery staff e.g. in a visibly open space where it would be at risk of theft or rain damage.<br>
									 
									If you are not home and the package cannot be put through the letter box, nor have you designated a safe location to leave the package; then a card will be left by the postman explaining how to request a re-delivery or where to collect the package from.<br>
									 
									You can either add a delivery note when checking out on our website; or if you are on a subscription, you can edit your delivery options in Accounts > Delivery. You can inform the postman of a designated location to leave the package if you are not home.<br>
									 
									There may be instances where your delivery is delayed due to circumstances out of our control. We cannot assume responsibility for these delays, but we will do everything we can to ensure that the best service is provided to you.<br>
									 
									If your delivery has been delayed by more than 7 days, please contact us and we will issue a redelivery for your product/s free of charge.<br>
									 
									Please note, all our services are only available to UK residents. We only deliver to addresses within the UK.</div>
								</div>

								<div class="toggle faq faq-delivery">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Can I track my delivery?
										</div>
									</div>
									<div class="toggle-content">You can order by standard post in which case the item can be put through your letterbox or left in your designated delivery location without requiring you to be present to receive it. This service cannot be tracked.<br>
 
									Alternatively, you can pay the additional £2.50 charge and have it posted by Royal Mail Recorded Delivery which requires a signature upon delivery. A tracking number will be provided upon dispatch which can be checked on the Royal Mail website:<br>
									 
									<a href="https://www.royalmail.com/track-your-item#/" target="blank">https://www.royalmail.com/track-your-item#/</a><br>
									 
									This service is not appropriate for customers where it is unlikely someone will be at the delivery address to receive the order.
									</div>
								</div>

								<div class="toggle faq faq-delivery">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Is the packaging discreet?
										</div>
									</div>
									<div class="toggle-content">100% discreet - we only use plain packaging with no branding or labels.
									</div>
								</div>

								<div class="toggle faq faq-delivery">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Do you deliver outside the UK?
										</div>
									</div>
									<div class="toggle-content">No, we are regulated by the CQC and therefore not permitted to post medication outside of the UK.</div>
								</div>

								<div class="toggle faq faq-delivery">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											It’s been a week and my order has not arrived?
										</div>
									</div>
									<div class="toggle-content">Please contact our customer service department via our website. We will look into this and get back to you as soon as we can.</div>
								</div>

								<div class="toggle faq faq-delivery">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											What should I do with medication I no longer need?
										</div>
									</div>
									<div class="toggle-content">If you no longer need the medication, please take it to any local pharmacy and they will be able to safely dispose of it.</div>
								</div>

								<div class="toggle faq faq-clinic">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											What is Erectile Dysfunction (ED)?
										</div>
									</div>
									<div class="toggle-content">ED is more commonly known as impotence, it is a common condition which affects many men, resulting in the inability to achieve and maintain an erection for sexual intercourse.</div>
								</div>

								<div class="toggle faq faq-clinic">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Is a prescription medication required?
										</div>
									</div>
									<div class="toggle-content">It is possible for ED to be reversed without medication through focus on lifestyle changes such as moving to a healthy diet, quitting smoking, increasing exercise and avoiding excessive alcohol consumption. Where this is not effective or an option then ‘over the counter’ and prescription medication can help alleviate the symptoms.</div>
								</div>

								<div class="toggle faq faq-clinic">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Are the medications you provide genuine? Are they the same as if I went to a high street pharmacy?
										</div>
									</div>
									<div class="toggle-content">We supply the exact same medications as your local pharmacy in the high street. In fact, all our medications are dispensed by our Pharmacy Partner that is a traditional high street pharmacy, regulated by the GPhC, similar to all the other pharmacies in the UK. Our patients prefer to order from us for convenience, speed of delivery, privacy and trusted advice from our Proman Clinical Team. They also choose us over other pharmacies because we pride ourselves in providing the best and cheapest prices in the market.</div>
								</div>

								<div class="toggle faq faq-clinic">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Do I need a prescription to order?
										</div>
									</div>
									<div class="toggle-content">An existing prescription is not required. We offer a free medical consultation which allows us to ascertain your symptoms and medical history. This is then reviewed by our Proman Clinical Team, who then electronically issue private prescriptions to our Partner Pharmacy. The medication is then dispensed and delivered via Royal Mail.</div>
								</div>

								<div class="toggle faq faq-clinic">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Are the medications you provide safe?
										</div>
									</div>
									<div class="toggle-content">We will not prescribe any medication until a medical consultation has been reviewed by our Proman Clinical Team. Our clinicians will review your existing and past medical history to assess the safe and suitability of the treatment.<br>
									If the treatment is deemed unsafe for you based on your medical history, we will not be able to prescribe the medication to you. Instead, we will refer you to your GP for further investigation or assessment.<br>
									We operate under the same regulations as your local GP. We are regulated by the Care Quality Commission (CQC) and our Pharmacist Prescribers and Partner Pharmacy are regulated by the General Pharmaceutical Council (GPhC).
									</div>
								</div>

								<div class="toggle faq faq-clinic">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											I have heard of Viagra, but what is Sildenafil/Tadalafil?
										</div>
									</div>
									<div class="toggle-content">Viagra Connect, Viagra and Sildenafil all contain the same active ingredient: Sildenafil Citrate. The makers of Viagra lost its patency in 2018, resulting in the production of the generic alternative by several pharmaceutical companies. This naturally led to the prices of this medication (and others) dropping significantly compared to the branded alternatives.<br>
									Sildenafil Citrate is a chemical that temporarily increases blood flow to the penis, enabling an erection when sexually aroused. Because all three treatments contain Sildenafil Citrate as their active ingredient, they all work in exactly the same way.
									</div>
								</div>

								<div class="toggle faq faq-privacy">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Is the service confidential? Is my medical information secure?
										</div>
									</div>
									<div class="toggle-content">Your medical data, medication order history and personal details are totally confidential in compliance with the UK regulations. They will only be viewable by our Proman Clinical Team and the dispensing technicians at our Partner Pharmacy.<br>
									Please view our privacy policy for further details. Information will not be shared to third parties such as your GP unless expressly authorised by you.
									</div>
								</div>

								<div class="toggle faq faq-privacy">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Why is ID verification required?
										</div>
									</div>
									<div class="toggle-content">We provide prescription medication after our short online medical questionnaire is completed, and then approved by the Proman Clinical Team. We must verify that the person requesting the medication is who they say they are, to ensure the medications are safe and appropriate for the person requesting it. Moreover, by law we have to confirm the ID verification of each patient in compliance with the regulating body i.e. Care Quality Commission.<br>
									When you go through our ordering process, our ID verification partners will run an ID check on your details to confirm the name, date of birth and address are correct. Sometimes this verification process fails, in which case we will contact you directly to send us scanned copies of your ID such as your driving license or passport.
									</div>
								</div>

								<div class="toggle faq faq-account">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											I’ve forgotten my password and/or username?
										</div>
									</div>
									<div class="toggle-content"></div>
								</div>

								<div class="toggle faq faq-account">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How do I cancel my repeat prescription?
										</div>
									</div>
									<div class="toggle-content"></div>
								</div>

								<div class="toggle faq faq-account">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How do I pause my order?
										</div>
									</div>
									<div class="toggle-content"></div>
								</div>

								<div class="toggle faq faq-account">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How and when is payment taken?
										</div>
									</div>
									<div class="toggle-content"></div>
								</div>

								<div class="toggle faq faq-account">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How can I delete my account?
										</div>
									</div>
									<div class="toggle-content"></div>
								</div>

								<div class="toggle faq faq-account">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											How can I change my repeat prescription quantity and/or change treatment?
										</div>
									</div>
									<div class="toggle-content"></div>
								</div>

								<div class="toggle faq faq-billing">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Can I cancel my order?
										</div>
									</div>
									<div class="toggle-content">If you contact us before the medication has been dispatched by our partner pharmacy, then we can cancel the order and process your refund. Unfortunately, once the medication has been posted we are unable to cancel the order or accept a return as medication can not be reused as per the UK regulations on medicines.</div>
								</div>

								<div class="toggle faq faq-billing">
									<div class="toggle-header">
										<div class="toggle-icon">
											<i class="toggle-closed icon-question-sign"></i>
											<i class="toggle-open icon-question-sign"></i>
										</div>
										<div class="toggle-title">
											Can I return the medication for a refund?
										</div>
									</div>
									<div class="toggle-content">We cannot accept returns as it is illegal for medication to be reused once it has left the pharmacy. The only instance in which we will refund you is if there was an error on our part or the medication arrived damaged to your chosen address. Please contact our customer service team if that happens; we will give you details on how to return the medication back to us along with details of the refund process.</div>
								</div>

							</div>
						
					</div>

				</div>

			</div>
		</section>

		<div class="clear"></div>

		<?php echo $__env->yieldContent('page_content'); ?>
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		<?php echo $__env->make('Frontend.Master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	<?php echo $__env->make('Frontend.Master.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
	<script>
		jQuery(document).ready(function($){
			var $faqItems = $('#faqs .faq');
			if( window.location.hash != '' ) {
				var getFaqFilterHash = window.location.hash;
				var hashFaqFilter = getFaqFilterHash.split('#');
				if( $faqItems.hasClass( hashFaqFilter[1] ) ) {
					$('.grid-filter li').removeClass('activeFilter');
					$( '[data-filter=".'+ hashFaqFilter[1] +'"]' ).parent('li').addClass('activeFilter');
					var hashFaqSelector = '.' + hashFaqFilter[1];
					$faqItems.css('display', 'none');
					if( hashFaqSelector != 'all' ) {
						$( hashFaqSelector ).fadeIn(500);
					} else {
						$faqItems.fadeIn(500);
					}
				}
			}

			$('.grid-filter a').on( 'click', function(){
				$('.grid-filter li').removeClass('activeFilter');
				$(this).parent('li').addClass('activeFilter');
				var faqSelector = $(this).attr('data-filter');
				$faqItems.css('display', 'none');
				if( faqSelector != 'all' ) {
					$( faqSelector ).fadeIn(500);
				} else {
					$faqItems.fadeIn(500);
				}
				return false;
		   });
		});
	</script>
</body>
</html><?php /**PATH /home/proman/public_html/pharmacy-master/resources/views/faq.blade.php ENDPATH**/ ?>