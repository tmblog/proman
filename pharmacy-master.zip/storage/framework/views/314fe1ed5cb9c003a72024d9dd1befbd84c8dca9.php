<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Montserrat:400,700|Crete+Round:400i&display=swap" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/style.css" rel="stylesheet" type="text/css">
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/images/favicon.png">
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/dark.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/animate.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/swiper.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/custom.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/proman-icons.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/colors.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/fonts.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/proman.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/css/datepicker.css" type="text/css" />
	<meta name='viewport' content='initial-scale=1, viewport-fit=cover'>
	<!-- / -->
	<?php /**PATH /home/proman/public_html/pharmacy-master/resources/views/Frontend/Master/header.blade.php ENDPATH**/ ?>