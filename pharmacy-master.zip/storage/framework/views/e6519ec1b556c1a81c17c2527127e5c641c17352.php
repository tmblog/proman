<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php echo $__env->make('Frontend.Master.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<meta name="description" content="Competitive prices on Women's medications and treatments, order online with free consultation. ProMan health is an online Pharmacy."/>
<!-- Document Title
============================================= -->
<title>Women's Health & Medications Order Online Pharmacy | ProMan Health</title>
<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<?php echo $__env->make('Frontend.Master.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- #header end -->



		<!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">
					<div class="heading-block border-bottom-0 bottommargin-sm">
						<h1 class="nott ls0">Women's Health</h1>
					</div>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis</p>
					<div class="row col-mb-50 mb-0">
						 
						  <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($single_category['type'] == 4): ?>
							<div class="col-sm-6 col-lg-3">
								
								<div class="card" style="background:#35c0ed;">
								  <img src="/storage/<?php echo e($single_category->image); ?>" class="card-img-top" alt="<?php echo e($single_category['name']); ?> image">
								  <div class="card-body p-2 text-center">

									<a href="/treatments/<?php echo e($single_category->slug); ?>" class="dark font-weight-bold"><?php echo e($single_category['name']); ?></a>
								  </div>
								</div>

							</div>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</div>

					<div class="fancy-title title-border">
						<h3>How it works</h3>
					</div>

					<div class="row justify-content-center col-mb-50 mb-0">
						<div class="col-sm-6 col-lg-4">
							<div class="feature-box fbox-center fbox-bg fbox-light fbox-effect">
								<div class="fbox-icon">
									<a href="#"><i>1</i></a>
								</div>
								<div class="fbox-content">
									<h3>Select Treatment<span class="subtitle text-dark">Choose the medication from our range of treatments</span></h3>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-lg-4">
							<div class="feature-box fbox-center fbox-bg fbox-border fbox-effect">
								<div class="fbox-icon">
									<a href="#"><i>2</i></a>
								</div>
								<div class="fbox-content">
									<h3>Complete Questionnaire<span class="subtitle text-dark">Submit the medical consultation for review by the Proman Clinical Team</span></h3>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-lg-4">
							<div class="feature-box fbox-center fbox-bg fbox-outline fbox-effect">
								<div class="fbox-icon">
									<a href="#"><i>3</i></a>
								</div>
								<div class="fbox-content">
									<h3>Express Delivery<span class="subtitle text-dark">Medication dispensed from Partner Pharmacy & delivered by Royal Mail</span></h3>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>
		</section>

		<div class="clear"></div>

		<?php echo $__env->yieldContent('page_content'); ?>
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		<?php echo $__env->make('Frontend.Master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	<?php echo $__env->make('Frontend.Master.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/proman/public_html/pharmacy-master/resources/views/womens-health.blade.php ENDPATH**/ ?>