<!-- Top Bar
   ============================================= -->
   <div id="top-bar">
	<div class="container clearfix">
	   <div class="row justify-content-between">
		  <div class="col-12 col-md-auto d-none d-md-flex">
			
		  </div>
		  <div class="col-12 col-md-auto">
			 <!-- Top Links
				============================================= -->
			 <div class="top-links">
				<ul class="top-links-container">
				    <?php if(Auth::check()): ?>
				   <li class="top-links-item">
					  <a a class="menu-link" href="#"><?php echo e(Auth::user()->email); ?></a>
					  <ul class="sub-menu-container">
						 <li class="top-links-item">
							<?php if(Auth::user()->role_id == 2): ?>
							<a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/patient/dashboard">Dashboard</a>
							<?php endif; ?>
							<?php if(Auth::user()->role_id == 3): ?>
							<a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/pharmacist/dashboard">Dashboard</a>
							<?php endif; ?>
							<?php if(Auth::user()->role_id == 4): ?>
							<a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/consultant/dashboard">Dashboard</a>
							<?php endif; ?>
						 </li>
						 <li class="menu-item">
							<a class="menu-link" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
						 </li>
					  </ul>
				   </li>
				   <?php else: ?>
				   <li class="top-links-item"><a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/login">Login/Register</a></li>
				   <?php endif; ?>
				   <li class="top-links-item"><a href="https://promanhealth.co.uk/contact" class="bg-color text-white">Contact</a></li>
				</ul>
			 </div>
			 <!-- .top-links end -->
		  </div>
	   </div>
	</div>
 </div>
 <!-- #top-bar end -->
 <!-- Header
	============================================= -->
 <header id="header" data-menu-padding="28" data-sticky-menu-padding="8">
	<div id="header-wrap">
	   <div class="container">
		  <div class="header-row">
			 <!-- Logo
				============================================= -->
			 <div id="logo">
				<a href="/" class="standard-logo"><img src="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/images/proman-health-logo-web-trans.png" alt="Proman Health Logo"></a>
				<a href="/" class="retina-logo"><img src="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/images/proman-health-logo-web-trans.png" alt="Proman Health Logo"></a>
			 </div>
			 <!-- #logo end -->
			 <div id="primary-menu-trigger">
				<svg class="svg-trigger" viewBox="0 0 100 100">
				   <path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path>
				   <path d="m 30,50 h 40"></path>
				   <path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path>
				</svg>
			 </div>
			 <!-- Primary Navigation
				============================================= -->
			 <nav class="primary-menu style-3 menu-spacing-margin">
				<ul class="menu-container">
				   <li class="menu-item current">
					  <a class="menu-link" href="/">
						 <div>Home</div>
					  </a>
				   </li>
				   <li class="menu-item">
					  <a class="menu-link" href="#">
						 <div>About Us</div>
					  </a>
					  <ul class="sub-menu-container">
						 <li class="menu-item">
							<a class="menu-link" href="https://promanhealth.co.uk/about-proman-health">
							   <div>Proman Health</div>
							</a>
						 </li>
						 <li class="menu-item">
							<a class="menu-link" href="https://promanhealth.co.uk/proman-clinical-team">
							   <div>Proman Clinical Team</div>
							</a>
						 </li>
						 <li class="menu-item">
							<a class="menu-link" href="https://promanhealth.co.uk/partner-pharmacy">
							   <div>Partner Pharmacy</div>
							</a>
						 </li>
						 <li class="menu-item">
							<a class="menu-link" href="https://promanhealth.co.uk/regulation">
							   <div>Regulation</div>
							</a>
						 </li>
						 <li class="menu-item">
							<a class="menu-link" href="https://promanhealth.co.uk/contact">
							   <div>Contact</div>
							</a>
						 </li>
					  </ul>
				   </li>
				   <li class="menu-item">
					  <a class="menu-link" href="https://promanhealth.co.uk/mens-health">
						 <div>Men</div>
					  </a>
					  <ul class="sub-menu-container">
						 <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($single_category['menu_place'] == 0): ?>
							<li class="menu-item">
								<a class="menu-link" href="https://promanhealth.co.uk/treatments/<?php echo e($single_category['slug']); ?>">
								   <div><?php echo e($single_category['name']); ?></div>
								</a>
							</li>
							<?php endif; ?>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </ul>
				   </li>
				   <li class="menu-item">
					  <a class="menu-link" href="https://promanhealth.co.uk/womens-health">
						 <div>Women</div>
					  </a>
					   <ul class="sub-menu-container">
						 <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($single_category['menu_place'] == 4): ?>
							<li class="menu-item">
								<a class="menu-link" href="https://promanhealth.co.uk/treatments/<?php echo e($single_category['slug']); ?>">
								   <div><?php echo e($single_category['name']); ?></div>
								</a>
							</li>
							<?php endif; ?>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </ul>
				   </li>
				   <li class="menu-item">
					  <a class="menu-link" href="https://promanhealth.co.uk/general-health">
						 <div>General Health</div>
					  </a>
					   <ul class="sub-menu-container">
						 <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($single_category['menu_place'] == 1): ?>
							<li class="menu-item">
								<a class="menu-link" href="https://promanhealth.co.uk/treatments/<?php echo e($single_category['slug']); ?>">
								   <div><?php echo e($single_category['name']); ?></div>
								</a>
							</li>
							<?php endif; ?>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </ul>
				   </li>
				   <li class="menu-item">
					  <a class="menu-link" href="https://promanhealth.co.uk/travel-health">
						 <div>Travel Health</div>
					  </a>
					   <ul class="sub-menu-container">
						 <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($single_category['menu_place'] == 2): ?>
							<li class="menu-item">
								<a class="menu-link" href="https://promanhealth.co.uk/treatments/<?php echo e($single_category['slug']); ?>">
								   <div><?php echo e($single_category['name']); ?></div>
								</a>
							</li>
							<?php endif; ?>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </ul>
				   </li>
				   <li class="menu-item">
					  <a class="menu-link" href="https://promanhealth.co.uk/prescription">
						 <div>Prescriptions</div>
					  </a>
				   </li>
				   <!-- <li class="menu-item">
					  <a class="menu-link" href="https://promanhealth.co.uk/treatments/blood-tests">
						 <div>Blood Tests</div>
					  </a>
				   </li> -->
				   
				   <!-- <?php if(Auth::check()): ?>
				   <li class="menu-item">
					  <a a class="menu-link" href="#"><?php echo e(Auth::user()->email); ?></a>
					  <ul class="sub-menu-container">
						 <li class="menu-item">
							<?php if(Auth::user()->role_id == 2): ?>
							<a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/patient/dashboard">Dashboard</a>
							<?php endif; ?>
							<?php if(Auth::user()->role_id == 3): ?>
							<a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/pharmacist/dashboard">Dashboard</a>
							<?php endif; ?>
							<?php if(Auth::user()->role_id == 4): ?>
							<a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/consultant/dashboard">Dashboard</a>
							<?php endif; ?>
						 </li>
						 <li class="menu-item">
							<a class="menu-link" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
						 </li>
					  </ul>
				   </li>
				   <?php else: ?>
				   <li class="menu-item"><a class="menu-link" href="<?php echo e(env('APP_URL')); ?>/login">Login</a></li>
				   <?php endif; ?> -->
				</ul>
			 </nav>
			 <!-- #primary-menu end -->
		  </div>
	   </div>
	</div>
	<div class="header-wrap-clone"></div>
	<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	   <div class="modal-dialog" role="document">
		  <div class="modal-content">
			 <div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">×</span>
				</button>
			 </div>
			 <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
			 <div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
				<a href="<?php echo e(route('logout')); ?>" class="btn btn-primary" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
				Logout
				</a>
				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
				   <?php echo csrf_field(); ?>
				</form>
			 </div>
		  </div>
	   </div>
	</div>
 </header>
 <!-- #header end --><?php /**PATH /home/proman/public_html/pharmacy-master/resources/views/Frontend/Master/nav.blade.php ENDPATH**/ ?>