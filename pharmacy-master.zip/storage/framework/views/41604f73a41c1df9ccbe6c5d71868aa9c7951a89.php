		<footer id="footer" style="background-color: #08376b;" class="dark">
			<div class="container">
				<!-- Footer Widgets
				============================================= -->
				<div class="footer-widgets-wrap py-5">

					<div class="row col-mb-50">
						<div class="col-md-4">

							<div class="widget">
								<div class="row col-mb-30 ml-1">
									<img src="<?php echo e(env('PUBLIC_PATH')); ?>/frontend/images/proman-health-footer-logo-white.png" alt="Proman Health Logo" style="max-width:250px;border-bottom:1px solid white">
									<p>14/2G Docklands Business Centre<br>
									10-16 Tiller Road<br>
									London<br>
									E14 8PX</p>
								</div>
							</div>
						</div>
						<div class="col-md-8">
							<div class="widget clearfix">

								<div class="row col-mb-30">
									<div class="col-6 col-lg-3 widget_links">
										<h5>Online Services</h5>
										<ul>
											<li><a href="#">All Services</a></li>
											<li><a href="#">Popular Treatment</a></li>
											<li><a href="https://promanhealth.co.uk/treatments/blood-tests">Blood Tests</a></li>
											<li><a href="https://promanhealth.co.uk/multimedia">Multimedia</a></li>
											<li><a href="https://promanhealth.co.uk/health-blog">Health Blog</a></li>
											<li><a href="https://promanhealth.co.uk/useful-links">Useful Links</a></li>
										</ul>
									</div>

									<div class="col-6 col-lg-3 widget_links">
										<h5>ProMan Health</h5>
										<ul>
											<li><a href="https://promanhealth.co.uk/proman-clinical-team">Clinical Team</a></li>
											<li><a href="https://promanhealth.co.uk/partner-pharmacy">Partner Pharmacy</a></li>
											<li><a href="https://promanhealth.co.uk/how-it-works">How it works</a></li>
											<li><a href="https://promanhealth.co.uk/reviews">Reviews</a></li>
											<li><a href="https://promanhealth.co.uk/trust-pilot">Trust Pilot</a></li>
											<li><a href="https://promanhealth.co.uk/faq">FAQ</a></li>
											<li><a href="https://promanhealth.co.uk/login">Login</a></li>
										</ul>
									</div>

									<div class="col-6 col-lg-3 widget_links">
										<h5>Social Media</h5>
										<ul>
											<li><a href="#">Facebook</a></li>
											<li><a href="#">Instagram</a></li>
											<li><a href="#">Twitter</a></li>
											<li><a href="#">YouTube</a></li>
										</ul>
									</div>

									<div class="col-6 col-lg-3 widget_links">
										<h5>Customer Service</h5>
										<ul>
											<li><a href="https://promanhealth.co.uk/subscription">Subscription</a></li>
											<li><a href="https://promanhealth.co.uk/payment">Payment</a></li>
											<li><a href="https://promanhealth.co.uk/refunds-returns">Refund & Returns</a></li>
											<li><a href="https://promanhealth.co.uk/delivery-information">Delivery</a></li>
											<li><a href="https://promanhealth.co.uk/complaints-feedback">Complaints & Feedback</a></li>
											<li><a href="https://promanhealth.co.uk/contact">Contact</a></li>
										</ul>
									</div>
								</div>

							</div>
						</div>

					</div>

				</div><!-- .footer-widgets-wrap end -->
			</div>

			<!-- Copyrights
			============================================= -->
			<div id="copyrights" style="background:#02264f;" class="dark">
				<div class="container clearfix">

					<div class="row col-mb-30">
						<div class="col-md-12 text-center text-md-left">
							Copyright &copy; <?php echo date("Y");?> All Rights Reserved by ProMan Health.<br>
							<div class="copyright-links"><a href="https://promanhealth.co.uk/regulation">Regulation</a>|<a href="https://promanhealth.co.uk/terms-and-conditions">Terms & Conditions</a>|<a href="https://promanhealth.co.uk/terms-of-sale">Terms of Sale</a>|<a href="https://promanhealth.co.uk/privacy">Privacy Policy</a>|<a href="https://promanhealth.co.uk/cookies-policy">Cookie Policy</a>|<a href="https://promanhealth.co.uk/careers">Careers</a></div>
						</div>
					</div>

				</div>
			</div><!-- #copyrights end -->
		</footer><!-- #footer end --><?php /**PATH /home/proman/public_html/pharmacy-master/resources/views/Frontend/Master/footer.blade.php ENDPATH**/ ?>