<!DOCTYPE html>
<html dir="ltr" lang="en-US">
@include('Frontend.Master.header')
<meta name="description" content=""/>
<!-- Document Title
============================================= -->
<title>Contact Form | Proman Health</title>

</head>

<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		@include('Frontend.Master.nav')
        <!-- #header end -->

		<!-- Content
		============================================= -->
		@if(session('status'))
			<p class="alert alert-success">Email sent successfully</p>
		@endif
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">
					<div class="heading-block border-bottom-0 bottommargin-sm">
						<h1 class="nott ls0">Contact Request</h1>
					</div>
					<div class="col-lg-12 p-0">
						<div class="form-widget" >
							
							<div class="form-result"></div>
							<form class="row mb-0" id="contact-us" method="post" action="/contactus">
								@csrf
								<div class="form-process">
									<div class="css3-spinner">
										<div class="css3-spinner-scaler"></div>
									</div>
								</div>
								<div class="col-md-4 form-group">
									<label for="template-medical-name">Name:</label>
									<input type="text" name="name" class="form-control not-dark required" value="">
								</div>
								<div class="col-md-4 form-group">
									<label for="template-medical-phone">Phone:</label>
									<input type="text" name="phone" class="form-control not-dark required" value="">
								</div>
								<div class="col-md-4 form-group">
									<label for="template-medical-email">Email Address:</label>
									<input type="email"  name="email" class="form-control not-dark required" value="">
								</div>
								
								<div class="col-md-12 form-group">
									<label for="template-medical-message">Message:</label>
									<textarea  name="message" class="form-control not-dark required" cols="30" rows="5"></textarea>
								</div>
								<div class="w-100"></div>
								
								<div class="col-12 form-group text-right">
									<button class="button button-white button-light button-rounded m-0" type="submit">Submit</button>
								</div>

							</form>

						</div>
					</div>
				</div>
			</div>
		</section>
		<script>
			document.getElementById('contact-us').onsubmit = function(e){
				e.preventDefault();
				document.getElementById('contact-us').submit();
			}
		</script>
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		@include('Frontend.Master.footer')
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	@include('Frontend.Master.footer_links')
    
</body>
</html>