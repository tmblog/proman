<!DOCTYPE html>
<html dir="ltr" lang="en-US">
@include('Frontend.Master.header')
<meta name="description" content="ProMan Health is an online Pharmacy and provider of Men's health including Erectile Dysfunction treatments. Order in confidence online."/>

<!-- Document Title
============================================= -->
<title>ProMan Health | Dedicated to Men's Health</title>
<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		@include('Frontend.Master.nav')
        <!-- #header end -->

		<!-- Slider
		============================================= -->
		<section id="slider" class="slider-element swiper_wrapper min-vh-50 min-vh-md-100" data-loop="true" data-autoplay="5000">
			<div class="slider-inner">

				<div class="swiper-container swiper-parent">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<div class="container">
								<div class="slider-caption slider-caption-right" style="max-width: 700px;">
									<div>
										<h2 data-animate="flipInX">Erectile Dysfunction <span>Treatments</span></h2>
										<!-- <p class="d-none d-sm-block" data-animate="flipInX" data-delay="500">Competitive prices same day despatch from our registered Pharmacy</p> -->
									</div>
								</div>
							</div>
							<div class="swiper-slide-bg" style="background-image: url('{{env('PUBLIC_PATH')}}/frontend/images/proman-health-mens-health-supplies.jpg');"></div>
						</div>

						<div class="swiper-slide">
							<div class="container">
								<div class="slider-caption slider-caption-right" style="max-width: 700px;">
									<div>
										<h2 data-animate="flipInX">Hair Loss <span>Treatment</span></h2>
										<!-- <p class="d-none d-sm-block" data-animate="flipInX" data-delay="500">Competitive prices same day despatch from our registered Pharmacy</p> -->
									</div>
								</div>
							</div>
							<div class="swiper-slide-bg" style="background-image: url('{{env('PUBLIC_PATH')}}/frontend/images/proman-health-hairloss-treatments.jpg');"></div>
						</div>

						<div class="swiper-slide">
							<div class="container">
								<div class="slider-caption slider-caption-right" style="max-width: 700px;">
									<div>
										<h2 data-animate="flipInX">Travel Health <span>Medicines</span></h2>
										<!-- <p class="d-none d-sm-block" data-animate="flipInX" data-delay="500">Competitive prices same day despatch from our registered Pharmacy</p> -->
									</div>
								</div>
							</div>
							<div class="swiper-slide-bg" style="background-image: url('{{env('PUBLIC_PATH')}}/frontend/images/proman-health-travel-medicines.jpg');"></div>
						</div>
					
					</div>

				</div>

			</div>
		</section><!-- #slider end -->

		<!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">

						<div class="row mb-5">
							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-medical-i-first-aid i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">UK Registered Pharmacy</h5>
										
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-check1 i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">UK Regulated Medication</h5>
										
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-user-lock i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">UK Qualified Pharmacists</h5>
										
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-truck2 i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">Next Day Delivery Available</h5>
									</div>
								</div>
							</div>

						</div>
					
						<!-- <div class="row mb-5">
							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-lock1 i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">Discreet & Confidential</h5>
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-gbp i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">Lowest Price Guarantee</h5>
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-notes-medical i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">Free Medical Consultations</h5>
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6">
								<div class="feature-box fbox-outline fbox-dark fbox-effect clearfix">
									<div class="fbox-icon">
										<a href="#"><i class="icon-city i-alt" style="background-color: #08376b;"></i></a>
									</div>
									<div class="fbox-content">
										
										<h5 class="m-0">London Based Pharmacy</h5>
									</div>
								</div>
							</div>

						</div> -->

					<!-- <div class="row col-mb-50 mb-0">
						<div class="col-sm-6 col-md-4">
							<div class="feature-box fbox-plain">
								<div class="fbox-icon" data-animate="bounceIn">
									<a href="#"><i class="icon-medical-i-cardiology"></i></a>
								</div>
								<div class="fbox-content">
									<h3>Registered</h3>
									<p>Powerful Layout with Responsive functionality that can be adapted to any screen size. Resize browser to view.</p>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-md-4">
							<div class="feature-box fbox-plain">
								<div class="fbox-icon" data-animate="bounceIn" data-delay="200">
									<a href="#"><i class="icon-medical-i-social-services"></i></a>
								</div>
								<div class="fbox-content">
									<h3>Discreet</h3>
									<p>Looks beautiful &amp; ultra-sharp on Retina Screen Displays. Retina Icons, Fonts &amp; all others graphics are optimized.</p>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-md-4">
							<div class="feature-box fbox-plain">
								<div class="fbox-icon" data-animate="bounceIn" data-delay="400">
									<a href="#"><i class="icon-medical-i-neurology"></i></a>
								</div>
								<div class="fbox-content">
									<h3>Secure</h3>
									<p>Canvas includes tons of optimized code that are completely customizable and deliver unmatched fast performance.</p>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-md-4">
							<div class="feature-box fbox-plain">
								<div class="fbox-icon" data-animate="bounceIn">
									<a href="#"><i class="icon-medical-i-dental"></i></a>
								</div>
								<div class="fbox-content">
									<h3>Expert Consultations</h3>
									<p>Powerful Layout with Responsive functionality that can be adapted to any screen size. Resize browser to view.</p>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-md-4">
							<div class="feature-box fbox-plain">
								<div class="fbox-icon" data-animate="bounceIn" data-delay="200">
									<a href="#"><i class="icon-medical-i-imaging-root-category"></i></a>
								</div>
								<div class="fbox-content">
									<h3>Branded</h3>
									<p>Looks beautiful &amp; ultra-sharp on Retina Screen Displays. Retina Icons, Fonts &amp; all others graphics are optimized.</p>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-md-4">
							<div class="feature-box fbox-plain">
								<div class="fbox-icon" data-animate="bounceIn" data-delay="400">
									<a href="#"><i class="icon-medical-i-ambulance"></i></a>
								</div>
								<div class="fbox-content">
									<h3>Follow ups</h3>
									<p>Canvas includes tons of optimized code that are completely customizable and deliver unmatched fast performance.</p>
								</div>
							</div>
						</div>
					</div> -->

					<div class="row col-mb-50 mb-0">
						 
						 @foreach($all_categories as $single_category)
							@if ($single_category['frontpage'] == 1)
							<div class="col-sm-3 col-6 col-lg-3">
								
								<div class="card" style="background:#35c0ed;">
								  <img src="/storage/{{$single_category->image}}" class="card-img-top" alt="{{$single_category['name']}} image">
								  <div class="card-body p-2 text-center">

									<a href="/treatments/{{$single_category->slug}}" class="dark font-weight-bold">{{$single_category['name']}}</a>
								  </div>
								</div>

							</div>
							@endif
						@endforeach
						
					</div>

					<div class="col-mb-50 mb-0 text-center">
						<a href="all-medical-treatments" class="button button-border button-rounded button-fill fill-from-bottom button-blue"><span>View all treatments</span></a>
					</div>

					<div class="fancy-title title-border">
						<h3>How it works</h3>
					</div>

					<div class="row justify-content-center col-mb-50 mb-0">
						<div class="col-sm-6 col-lg-4">
							<div class="feature-box fbox-center fbox-bg fbox-light fbox-effect">
								<div class="fbox-icon">
									<i>1</i>
								</div>
								<div class="fbox-content">
									<h3>Select Treatment<span class="subtitle text-dark">Choose the medication from our range of treatments</span></h3>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-lg-4">
							<div class="feature-box fbox-center fbox-bg fbox-border fbox-effect">
								<div class="fbox-icon">
									<i>2</i>
								</div>
								<div class="fbox-content">
									<h3>Complete Questionnaire<span class="subtitle text-dark">Submit the medical consultation for review by the Proman Clinical Team</span></h3>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-lg-4">
							<div class="feature-box fbox-center fbox-bg fbox-outline fbox-effect">
								<div class="fbox-icon">
									<i>3</i>
								</div>
								<div class="fbox-content">
									<h3>Express Delivery<span class="subtitle text-dark">Medication dispensed from Partner Pharmacy & delivered by Royal Mail</span></h3>
								</div>
							</div>
						</div>
					</div>

				</div>

				<div class="container clearfix">

					<div class="fancy-title title-border">
						<h3>ProMan Clinical Team</h3>
					</div>

					<div class="row col-mb-50 mb-0">
						<div class="col-sm-6 col-lg-4">

							<div class="team">
								<div class="team-image">
									<img src="https://picsum.photos/100" alt="Dr. John Doe" class="rounded-circle w-50 mx-auto">
								</div>
								<div class="team-desc">
									<div class="team-title"><h4>Dr. John Doe</h4><span>Cardiologist</span></div>
								</div>
							</div>

						</div>

						<div class="col-sm-6 col-lg-4">
							<div class="team">
								<div class="team-image">
									<img src="https://picsum.photos/100" alt="Dr. John Doe" class="rounded-circle w-50 mx-auto">
								</div>
								<div class="team-desc">
									<div class="team-title"><h4>Dr. Bryan Mcguire</h4><span>Orthopedist</span></div>
								</div>
							</div>
						</div>

						<div class="col-sm-6 col-lg-4">
							<div class="team">
								<div class="team-image">
									<img src="https://picsum.photos/100" alt="Dr. John Doe" class="rounded-circle w-50 mx-auto">
								</div>
								<div class="team-desc">
									<div class="team-title"><h4>Dr. Mary Jane</h4><span>Neurologist</span></div>
								</div>
							</div>
						</div>
						
					</div>

				</div>

			</div>
		</section>

		<div class="clear"></div>

		@yield('page_content')
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		@include('Frontend.Master.footer')
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	@include('Frontend.Master.footer_links')
    @stack('scripts')
</body>
</html>
