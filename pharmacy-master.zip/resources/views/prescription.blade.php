<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml"><head prefix="og: http://ogp.me/ns# scribd-com: http://ogp.me/ns/apps/scribd-com#"><link rel="preconnect" href="https://s-f.scribdassets.com/"><link rel="preload" crossorigin="anonymous" href="https://s-f.scribdassets.com/webpack/assets/fonts/source_sans_pro/regular/source_sans_pro_regular.latin.e8ecbdac.woff2" as="font" type="font/woff2"><link rel="preload" crossorigin="anonymous" href="https://s-f.scribdassets.com/webpack/assets/fonts/source_sans_pro/semibold/source_sans_pro_600.latin.76017e81.woff2" as="font" type="font/woff2"><link rel="preload" crossorigin="anonymous" href="https://s-f.scribdassets.com/webpack/assets/fonts/icons/icons.d2ecf18b.woff2" as="font" type="font/woff2"><script src="https://connect.facebook.net/en_US/sdk.js?hash=79075e82dde901de18d22a8ad8156c76" async="" crossorigin="anonymous"></script><title>Prescription</title><meta http-equiv="content-type" content="text/html;charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
      
      

<script src="https://s-f.scribdassets.com/webpack/vendors/react16/react16.63d55263784387ae046b.dll.js"></script><script type="text/javascript">
              window.i18next_lng = "en-US";
              window.i18next_fallback = "en-US";
              window.i18next_debug = "false";
            </script><script src="https://s-f.scribdassets.com/webpack/monolith/0.c5ff5131b77e1b3200d0.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/1.c8f3f716f6dbe3bb7667.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/2.bd7762230dcca50954a1.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/3.173d03e4bd0119745558.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/4.21ecb2c4862c74d0d807.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/7.ed804ecf48add651ff52.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/8.6129d337f420f3882d75.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/9.da915e3484ecd5c1d17b.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/10.a199d02d0ae094a4c4c8.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/11.5d7e28ac9ea651548ba7.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/20.9108c05db12a2332fb9f.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/22.2f6791dea11ade1f3bd6.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/40.9fefddb3a2dfc33df03f.js"></script><script src="https://s-f.scribdassets.com/webpack/monolith/embeds_new.bba683b384d98985d14e.js"></script><script src="https://browser.sentry-cdn.com/5.20.0/bundle.min.js" crossorigin="anonymous" integrity="sha384-mmBh0B1uYbzmP0q9QcqWr4el7gVXBSY0hWB2U8cNhNZi/RIuVQRp7pm1NlPOa644" id="sentry_script_tag" async=""></script><script>
window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
ga('create', "UA-443684-4"  , 'auto');
ga('send', 'pageview');
ga('set', 'dimension1', 'false');
ga('set', 'dimension3', document.location.host);
</script>
<script type="text/javascript">
        Scribd.download_document = {
          register_download_attempt_path: "/document_downloads/register_download_attempt",
          download_dialog_path: "/read/download_dialog",
          request_document_for_download_path: "/document_downloads/request_document_for_download"
        };
      </script><script type="text/javascript">
      Scribd.logged_in = false;
      Scribd.current_user = null;
      Scribd.archive_login_url = "https://www.scribd.com/archive/login";
      Scribd.google_auth_web_client_id = "491264573595-hs5hu9ijbfl9g6khnkn2retrfr6lcua7.apps.googleusercontent.com";
      Scribd.browser_uuid = "fcfbae93-a536-4082-9b2d-750361e2288b";
      Scribd.user_data = {};
    </script><script type="text/javascript">
          Scribd.current_doc = {};
          Scribd.root_url = "https://www.scribd.com/";
        </script><script type="text/javascript">
      window['$rat'] = ratInit(["https://rs1.scribd.com/","https://rs2.scribd.com/","https://rs3.scribd.com/","https://rs4.scribd.com/","https://rs5.scribd.com/","https://rs6.scribd.com/","https://rs7.scribd.com/","https://rs8.scribd.com/"], {"user_id":null,"doc_id":395514694}, true);
      $rat.root().withVid(function(vid) { $rat("gotvid", { vid: vid}) })
    </script><script type="text/javascript">
      window.webAnalytics = webAnalyticsInit("https://wa.scribd.com", {"user_id":null,"doc_id":395514694}, 100);
    </script><script type="text/javascript">Scribd.tracker = new Scribd.Tracker(document);</script><script defer="" type="application/javascript">if (typeof window.crossOriginIsolated !== "undefined" && !crossOriginIsolated) SharedArrayBuffer = ArrayBuffer;</script><style>div.ff0 span { font-family: ff0, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff1 span { font-family: ff1, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff2 span { font-family: ff2, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff3 span { font-family: ff3, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff4 span { font-family: ff4, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff5 span { font-family: ff5, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff6 span { font-family: ff6, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff7 span { font-family: ff7, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff8 span { font-family: ff8, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff9 span { font-family: ff9, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff10 span { font-family: ff10, Trebuchet MS1, Helvetica, sans-serif; font-weight: normal; font-style: italic;
}
div.ff11 span { font-family: ff11, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff12 span { font-family: ff12, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff13 span { font-family: ff13, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff14 span { font-family: ff14, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
div.ff15 span { font-family: ff15, Arial, Arial, Helvetica, sans-serif; font-weight: normal; font-style: normal;
}
.ff0, .ff1, .ff2, .ff3, .ff4, .ff5, .ff6, .ff7, .ff8, .ff9, .ff10, .ff11, .ff12, .ff13, .ff14, .ff15 { display: none; }
</style><style>#font_preload_bed span {display: block; visibility: hidden}</style><link href="https://html.scribdassets.com/2dn6cz0dds6otfcg/0,1,11,12,13,14,15,2,3,4,5,6,7,8,9,i10/12/ttfs.css" rel="stylesheet" type="text/css"><script src="https://browser.sentry-cdn.com/5.20.0/rewriteframes.min.js" crossorigin="anonymous" id="sentry_rewriteframe_script_tag" async=""></script><style type="text/css" data-fbcssmodules="css:fb.css.base css:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
.fb_mpn_mobile_landing_page_slide_out{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_out_from_left{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out_from_left;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_up{animation-duration:500ms;animation-name:fb_mpn_landing_page_slide_up;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_in{animation-duration:300ms;animation-name:fb_mpn_bounce_in;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out{animation-duration:300ms;animation-name:fb_mpn_bounce_out;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out_v2{animation-duration:300ms;animation-name:fb_mpn_fade_out;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_from_left{animation-duration:300ms;animation-name:fb_bounce_in_from_left;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_from_left{animation-duration:300ms;animation-name:fb_bounce_out_from_left;transition-timing-function:ease-in}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}@keyframes fb_mpn_landing_page_slide_out{0%{margin:0 12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;margin:0 24px;width:60px}}@keyframes fb_mpn_landing_page_slide_out_from_left{0%{left:12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;left:12px;width:60px}}@keyframes fb_mpn_landing_page_slide_up{0%{bottom:0;opacity:0}100%{bottom:24px;opacity:1}}@keyframes fb_mpn_bounce_in{0%{opacity:.5;top:100%}100%{opacity:1;top:0}}@keyframes fb_mpn_fade_out{0%{bottom:30px;opacity:1}100%{bottom:0;opacity:0}}@keyframes fb_mpn_bounce_out{0%{opacity:1;top:0}100%{opacity:.5;top:100%}}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_from_left{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}50%{transform:scale(1.03, 1.03);transform-origin:bottom left}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_from_left{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}}@keyframes slideInFromBottom{0%{opacity:.1;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}@keyframes slideInFromBottomDelay{0%{opacity:0;transform:translateY(100%)}97%{opacity:0;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}</style></head><body class="autogen_class_views_layouts_new_embed autogen_class_views_layouts_legacy_web autogen_class_views_layouts_web autogen_class_widgets_page autogen_class_widgets_base locale_en_US responsive body_container jsblock_done" data-revision="00ca3a6761e0f772a8207b6b3cbe57171a49d0e1" data-hj-ignore-attributes=""><script defer="" type="application/javascript">window.__initialState = JSON.parse("{\"__locale\":\"en-US\",\"__assetPath\":\"https://s-f.scribdassets.com/\"}");</script><div id="fb-root" class=" fb_reset"><script type="text/javascript" src="https://connect.facebook.net/en_US/sdk.js" async=""></script><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div></div></div></div>
<script type="text/javascript">
  Scribd.Facebook.setup()
</script><div class="auto__embeds_new_show autogen_class_widgets_base view_mode_scroll" id="autogen_id_800304338" data-track_category="embeds"><div class="document_scroller embed_test"><div class="document_container"><script type="text/javascript">DocumentManager.scrollParent = document.querySelector(".document_scroller")</script><script type="text/javascript">
  var defaultViewWidth = defaultViewWidth || 679.0;

  var docManager = new DocumentManager(
    "scroll",
    "web" == "mobile",
    { hasWoffFonts: false }
  ); // Our global manager for this view page
  window.docManager = docManager;
  docManager.setEmbeddedDoc('True');
  docManager.fontAggregatorHosts = ["https://html.scribdassets.com"];
  docManager.assetPrefix = "2dn6cz0dds6otfcg";
  docManager.addFont(11, "", "ff11", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(10, "i", "ff10", "Trebuchet MS1, Helvetica, sans-serif", "normal", "italic");
  docManager.addFont(13, "", "ff13", "Arial, Arial, Helvetica, sans-serif, "normal", "normal");
  docManager.addFont(12, "", "ff12", "Arial, Arial, Helvetica, sans-serif,  "normal", "normal");
  docManager.addFont(15, "", "ff15", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(14, "", "ff14", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(1, "", "ff1", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(0, "", "ff0", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(3, "", "ff3", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(2, "", "ff2", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(5, "", "ff5", "Arial, Arial, Helvetica, sans-serif,  "normal", "normal");
  docManager.addFont(4, "", "ff4", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(7, "", "ff7", "Arial, Arial, Helvetica, sans-serif,  "normal", "normal");
  docManager.addFont(6, "", "ff6", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(9, "", "ff9", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.addFont(8, "", "ff8", "Arial, Arial, Helvetica, sans-serif", "normal", "normal");
  docManager.displayType = "vector";
  docManager.initStyles();
  docManager.setPageWidths(defaultViewWidth);
  docManager.setImageDomainSubstitution(/http:\/\/html.scribd.com/, ["https://html.scribdassets.com"]);
</script>
<style>
  body{font-size:100%;width:100%;margin:0px;padding:0px;border:none}div.outer_page{position:relative;display:block;font-size:16px;margin:10px;margin-bottom:20px}div.blurred_page{-webkit-user-select:none;-khtml-user-drag:none;-khtml-user-select:none;-moz-user-select:none;-moz-user-select:-moz-none;-ms-user-select:none;user-select:none}div.outer_page.book_view{display:inline-block}div#page_wrapper{width:100%}div.page{left:0;position:relative;overflow:hidden;font-family:Helvetica, Times;top:0;line-height:1;color:#000000}div.layer{position:absolute;left:0;top:0;width:0;height:0}div.inner_layer{position:relative}div.abstext{position:absolute}.absimg{position:absolute;border:none}span.ib{overflow:hidden;white-space:nowrap;display:inline-block;vertical-align:bottom;letter-spacing:0}div.page div{white-space:nowrap}div.scale_hack div.middle_layer{font-size:15.0em}div.scale_hack div.inner_layer{-moz-transform:scale(0.06667);-moz-transform-origin:top left;-webkit-transform:scale(0.06667);-webkit-transform-origin:top left;-o-transform:scale(0.06667);-o-transform-origin:top left}span.nw{white-space:nowrap;position:static}span.jbr{width:100%;display:inline-block}.inner_layer div{position:absolute}.inner_layer p{position:absolute;margin:0;padding:0}.inner_layer p.pj span span{line-height:0px}.inner_layer p.pl span,.inner_layer p.pc span,.inner_layer p.pr span{line-height:0px}.inner_layer p.pj{white-space:normal;text-align:justify}.inner_layer p.pl{text-align:left}.inner_layer p.pr{text-align:right}.inner_layer p.pc{text-align:center}.inner_layer div span,.inner_layer p span{position:relative}.inner_layer div,.inner_layer span{white-space:nowrap}div.outer_page_container{position:relative}div.newpage{white-space:nowrap;position:relative;top:0px;left:0px;text-rendering:auto;color:#000000}div.image_layer{width:0px;height:0px;position:absolute;top:0px;left:0px}div.image_layer .absimg{position:absolute;border:none;left:0px}div.link_layer{width:0px;height:0px;position:absolute;top:0px;left:0px}div.text_layer div{white-space:nowrap;padding:0;margin:0;border:none;line-height:1}div.text_layer span{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1}span.g{position:absolute;border:none;left:0px}.text_layer span.w{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline-block}.text_layer a.ll{position:static;display:inline;color:inherit;text-decoration:none}.text_layer span.l{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline}.text_layer span.l1{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-1px}.text_layer span.l2{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-2px}.text_layer span.l3{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-3px}.text_layer span.l4{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-4px}.text_layer span.l5{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-5px}.text_layer span.l6{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-6px}.text_layer span.l7{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-7px}.text_layer span.l8{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-8px}.text_layer span.l9{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-9px}.text_layer span.l10{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-10px}.text_layer span.l11{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-11px}.text_layer span.l12{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;display:inline;margin-left:-12px}.text_layer span.w1{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:1px;display:inline-block}.text_layer span.w2{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:2px;display:inline-block}.text_layer span.w3{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:3px;display:inline-block}.text_layer span.w4{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:4px;display:inline-block}.text_layer span.w5{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:5px;display:inline-block}.text_layer span.w6{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:6px;display:inline-block}.text_layer span.w7{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:7px;display:inline-block}.text_layer span.w8{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:8px;display:inline-block}.text_layer span.w9{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:9px;display:inline-block}.text_layer span.w10{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:10px;display:inline-block}.text_layer span.w11{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:11px;display:inline-block}.text_layer span.w12{white-space:nowrap;padding:0;margin:0;border:none;height:1px;line-height:1;width:12px;display:inline-block}a.ll{display:block;position:absolute}div.text_layer{position:absolute;top:0;left:0;width:0;height:0;-o-transform:scale(0.2);-o-transform-origin:top left;-moz-transform:scale(0.2);-moz-transform-origin:top left;-webkit-transform:scale(0.2);-webkit-transform-origin:top left;-ms-transform:scale(0.2);-ms-transform-origin:top left;transform:scale(0.2);transform-origin:top left}span.a{position:absolute;border:none;left:0px}
</style>
<link rel="preload" href="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg" as="image">
<link rel="preload" href="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg" as="image">
<link rel="preload" href="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg" as="image">
<link rel="preload" href="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg" as="image">
<link rel="preload" href="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg" as="image">

<script type="text/javascript">
  docManager.setupTestElements();
</script>
<div role="document" tabindex="0" class="outer_page_container">
  
      
  
  <div class="outer_page only_ie6_border " id="outer_page_1" style="width: 822px; height: 1163px;">
      <div class="newpage" id="page1" style="width: 901px; height: 1274px; transform: scale(0.91232); transform-origin: left top;">
<div class="text_layer" style="z-index:2"><div class="ie_fix">
&nbsp;
<div class="ff0" style="font-size:84px">
<span class="a" style="left:545px;top:5791px">&nbsp;</span></div>
<div class="ff14" style="font-size:201px">
<span class="a" style="left:1457px;top:439px;word-spacing:-6px;color:#2e73b5">ProMan Health</span><br><span class="a" style="left:1457px;top:659px;word-spacing:-6px;font-size:100px;">Private Prescription</a></div>
<div class="ff5" style="font-size:101px">
<span class="a" style="left:618px;top:840px;word-spacing:-1px;color:#595959;font-size: 6rem;">{{$subscription->approved_by}} </span></div>
<div class="ff8" style="font-size:61px">
<span class="a" style="left:3051px;top:1040px;word-spacing:-1px;color:#595959;font-size: 5rem;">Phone: +447441222356 </span></div>
<div class="ff11" style="font-size:61px">
<span class="a" style="left:605px;top:1038px;word-spacing:-1px;color:#595959;font-size: 5rem;">14/2G Docklands Business Centre</span></div>
<div class="ff4" style="font-size:59px">
<span class="a" style="left:604px;top:1161px;word-spacing:3px;letter-spacing:-1px;color:#595959;font-size: 5rem;">10-16 Tiller Road<br> London<br>E14 8PX</span></div>
<div class="ff8" style="font-size:61px">
<span class="a" style="left:3049px;top:1168px;word-spacing:-1px;color:#595959;font-size: 5rem;">Email: info@promanhealth.co.uk</span></div>
<div class="ff7" style="font-size:61px">
<span class="a" style="left:614px;top:1630px;color:#595959">Patient Name: &nbsp; &nbsp; {{$subscription->patient->user->name}}</span></div>
<div class="ff12" style="font-size:65px">
<span class="a" style="left:605px;top:1842px;color:#595959">Address: &nbsp; &nbsp; {{$subscription->address->address_1}}</span></div>
<div class="ff15" style="font-size:80px">
<span class="a" style="left:2939px;top:1628px;color:#595959">Date of Birth: &nbsp; &nbsp; {{$subscription->patient->dob}}</span></div>
<div class="ff6" style="font-size:61px">
<span class="a" style="left:2937px;top:1831px;color:#595959">Date: &nbsp; &nbsp; {{$subscription->updated_at}}</span></div>
<div class="ff10" style="font-size:260px">
<span class="a" style="left:602px;top:2215px;color:#595959">R</span></div>
<div class="ff2" style="font-size:90px">
<span class="a" style="left:823px;top:2381px;color:#595959">x</span></div>
<span class="a" style="left:823px;top:2600px;color:#595959;font-size: 6rem;">{{$subscription->product->name}} {{$subscription->pack->name}} ({{$subscription->pack->strength->name}}) {{$subscription->duration}}</span><br>
<div class="ff9" style="font-size:111px">
<span class="a" style="left:599px;top:5676px;word-spacing:-2px;color:#595959">Independant Pharmacist Prescriber Signature: <br><br>{{$subscription->approved_by}}<br><br>GPhC Number: {{$subscription->gphc}}</span></div>

</div>
</div>
<div class="image_layer" style="z-index: 1">
<div class="ie_fix">
<img class="absimg" style="left:107px;top:290px;width:670px;height:61px;clip:rect(1px 669px 5px 1px)" src="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg">
<img class="absimg" style="left:196px;top:329px;width:670px;height:61px;clip:rect(12px 378px 57px 1px)" src="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg">
<img class="absimg" style="left:253px;top:326px;width:670px;height:61px;clip:rect(15px 523px 60px 380px)" src="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg">
<img class="absimg" style="left:107px;top:1060px;width:670px;height:61px;clip:rect(7px 669px 10px 1px)" src="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg">
<img class="absimg" style="left:-48px;top:1145px;width:670px;height:61px;clip:rect(12px 657px 13px 380px)" src="https://html.scribdassets.com/2dn6cz0dds6otfcg/images/1-35be5f6a6b.jpg">
</div>
</div>
</div>


    
  <div class="b_tl"></div>
  <div class="b_tr"></div>
  <div class="b_br"></div>
  <div class="b_bl"></div>
  <div class="b_t"></div>
  <div class="b_r"></div>
  <div class="b_b"></div>
  <div class="b_l"></div>

  </div>
  <script type="text/javascript">
    
    docManager.addPage({
      pageNum: 1,
      fonts: [0, 1, 3, 14, 5, 8, 11, 4, 7, 12, 15, 6, 10, 2, 9, 13],
      origWidth: 901,
      origHeight: 1274,
      containerElem: document.getElementById("outer_page_1"),
      blur: false,
      innerPageElem: document.getElementById("page1")
    });

  </script>



  <!--[if IE]>
  <script type='text/javascript'>
    window.docManagerIEAdded = true;
    if (document.observe) {
      document.observe('dom:loaded', function () {
          docManager.allPagesAdded();
        });
    } else {
      window.attachEvent('onload', function () {
          docManager.allPagesAdded();
        });
    }
  </script>
  <![endif]-->

  <script type="text/javascript">

    if (window.docManagerIEAdded != true) {
      docManager.allPagesAdded();
    }
  </script>

</div>








</body></html>