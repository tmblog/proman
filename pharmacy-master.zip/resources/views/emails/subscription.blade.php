@component('mail::message')
# Introduction

Hi {{$subscription->patient->user->name}},
{{$message}}

Thanks,<br>
{{ config('app.name') }}
@endcomponent
