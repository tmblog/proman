@extends('welcome')
@section('page_content')
<!-- Content
   ============================================= -->
<section id="content">
   <div class="content-wrap pb-0">
      <div class="container clearfix">
         <div class="row justify-content-center mb-5">
            <div class="col-lg-7 center">
               <div class="heading-block">
                  <h3 class="nott mb-3 font-weight-semibold ls0">{{$product['name']}}</h3>
                  <!-- <span class="text-black-50">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate corporis, facilis assumenda optio consequuntur amet iure, quidem animi nam inventore!</span> -->
               </div>
            </div>
         </div>
      </div>
      <div class="clear"></div>
      <form action="{{route('store-answer',[$category['slug'],$product['slug'],$pack->id])}}" method="post">
         @csrf   
         <div class="section section-features bg-transparent mt-0 p-0 clearfix">
            <div class="container clearfix">
               <div class="row col-mb-50 col-mb-lg-80">
                  <div class="col-md-12">
                     <div class="feature-box media-box">
                        @foreach($product['questions'] as $question)
                        @if($question['multiple_choice'] === 0)
                        <li>{{$question['question']}} <br>
                           @foreach($question['options'] as $option)
                           &emsp;<input type="radio" name="single[{{$question['id']}}]" class="form-check-input"  value="{{$option['id']}}">{{$option['option']}}<br>                                    
                           @endforeach
                        </li>
                        @elseif($question['multiple_choice'] === 1)
                        <li>{{$question['question']}} <br>
                           @foreach($question['options'] as $option)
                           &emsp;<input type="checkbox" name="multiple[{{$question['id']}}][]" class="form-check-input"  value="{{$option['id']}}">{{$option['option']}}<br>                                    
                           @endforeach
                        </li>
                        @elseif($question['multiple_choice'] === 2)
                        <li>{{$question['question']}} <br>
                           <input type="text" name="text[{{$question['id']}}]" class="form-control"><br>
                        </li>
                        @endif
                        @endforeach
                     </div>
                     <div class="form-group">
                        <button class="btn btn-primary" type="submit">Submit</button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </form>
   </div>
</section>
<!-- #content end -->
@endsection