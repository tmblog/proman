<script> window.baseUrl = '{{url('/')}}';</script>
<script> window.storageUrl = '{{env('STORAGE_URL')}}';</script>
<script> window.publicUrl = '{{env('PUBLIC_PATH')}}';</script>
<script> window.token = '{{@csrf_token()}}';</script>
<script> window.id = '';</script>


<script src="{{env('PUBLIC_PATH')}}/js/app.js" type="text/javascript"></script>
<script src="{{env('PUBLIC_PATH')}}/backend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="{{env('PUBLIC_PATH')}}/backend/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="{{env('PUBLIC_PATH')}}/backend/js/sb-admin-2.min.js"></script>
<script src="{{env('PUBLIC_PATH')}}/backend/js/custom.js"></script>
<!-- <script src="{{env('PUBLIC_PATH')}}/backend/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="{{env('PUBLIC_PATH')}}/backend/vendor/datatables/dataTables.bootstrap4.min.js"></script> -->
