@extends('Backend.Pharmacy.index')
@section('page_content')
<div class="container-fluid">
   <!-- Page Heading -->
   <!-- <h1 class="h3 mb-2 text-gray-800">Contact us request</h1> -->
   <!-- DataTales Example -->
   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary">All Orders</h6>
      </div>

      @if ($message = Session::get('success'))
      <div class="alert alert-success  alert-dismissible">
         <button type="button" class="close" data-dismiss="alert">×</button>   
         <strong>{{ $message }}</strong>
      </div>
      @endif

      @if ($message = Session::get('error'))
         <div class="alert alert-warning  alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>   
            <strong>{{ $message }}</strong>
         </div>
      @endif
      <div class="card-body">
         <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                  <th scope="col">Prescription Date</th>
				  <th scope="col">Full Name of Patient</th>
				  <th scope="col">DOB/Age</th>
				  <th scope="col">Biological Sex</th>
				  <th scope="col">Address</th>
                  <th scope="col">Medical Condition</th>
                  <th scope="col">Medicine (Strength/Quantity)</th>
                  <th scope="col">Order Status</th>
                  <th scope="col">Medical Consultation</th>
                  </tr>
               </thead>
               <tbody>
                   
               @foreach($orders as $order)
               <tr>
               <th>{{\Carbon\Carbon::parse($order->updated_at)->format('d/m/Y H:m')}}</th>
			   <th>{{$order->patient->user->name}}</th>
			   <?php
				$time = strtotime($order->patient->dob);
				$newformat = date('Y-m-d',$time);
			   ?>
			   <th>{{$order->patient->dob}}<br>{{\Carbon\Carbon::parse($newformat)->diff(\Carbon\Carbon::now())->format('%y years')}}</th>
			   <th>{{$order->patient->gender}}</th>
			   <th>{{$order->patient->city}} {{$order->patient->postcode}}</th>
               <th>{{$order->product->category->name}}</th>
               <th>{{$order->pack->name}}</th>
               <th>{{$order->order_status->title}}</th>
               <th>
                  <a href="{{route('order-show',$order)}}" title="view">View Details</a>
               </th>
               </tr>
               @endforeach
               </tbody>
            </table>

               <div class="dataTables_paginate paging_simple_numbers" id="dataTable_paginate">
                  {{$orders->links('pagination::bootstrap-4')}}
               </div>
         </div>
      </div>
   </div>
</div>

@endsection