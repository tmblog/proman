<!DOCTYPE html>
<html lang="en">
@include('Backend.Layouts.header')
<body id="page-top">
  <div id="wrapper">
  
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      @include('Backend.Pharmacy.Partials.nav')

        @yield('page_content')
        
      </div>
      <!-- End of Main Content -->

      @include('Backend.Layouts.footer')

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>  
@include('Backend.Layouts.logout_modal')
@include('Backend.Layouts.footer_links')

@stack('scripts')

</body>
</html>