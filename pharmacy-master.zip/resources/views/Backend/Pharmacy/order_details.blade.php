@extends('Backend.Pharmacy.index')
@section('page_content')
<div class="container-fluid">
   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-black">Orders from {{$order->patient->user->name}}</h6>
      </div>
      
      <div class="row">
         <div class="card-body">
            <div class="row">
               <div class="col-md-12">
                  <p>Order description of <b>{{$order->patient->user->name}}</b> on <b>{{\Carbon\Carbon::parse($order->updated_at)->format('d/m/Y H:m')}}</b></p>
               </div>
            </div>
            @if($order->order_status_id ==5)
            @error('order_status')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            <div class="row">
                <div class="col-md-8">
                <form class="form-inline" action="{{route('order-confirm')}}" method="post">
                    @csrf
                    <div class="form-group mx-sm-3 mb-2">
                        <label for="order_status"><b>Change Status:</b> &nbsp&nbsp</label>
                        <select name="order_status" id="" class="form-control">
                                <option value="0">Select status please</option>
                            @foreach($statuses as $status)
                                <option value="{{$status->id}}">{{$status->title}}</option>
                            @endforeach
                        </select>
                    </div>
                    <input type="hidden" name="order" value="{{$order->id}}">
                    <button type="submit" class="btn btn-primary btn-sm mb-2">Place Order</button>
                </form>
                </div>
            </div>
            @else
            <div class="row">
                <div class="col-md-12">
                <div class="card-body bg-danger">
                    <div class="py-3">
                        <h6 class="m-0 font-weight-bold text-white text-uppercase"> The order is {{$order->order_status->title}}</h6>
                    </div>
                </div>
                </div>
            </div>
            @endif
         </div>
      </div>
   </div>
   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary"><b>Order Details</b></h6>
         <div class="float-right"><a href="/prescription/{{$subscription->id}}" target="_blank" class="btn btn-success">Prescription</a></div>
      </div>
      <div class="card-body">
         <div class="table">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <tbody>
			      <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Prescription Date</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{\Carbon\Carbon::parse($subscription->created_at)->format('d/m/Y H:m')}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>ID Number</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->patient->user->id}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Full Name of Patient</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->patient->user->name}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
							<?php
							$time = strtotime($order->patient->user->dob);
							$newformat = date('Y-m-d',$time);
						   ?>
                           <p><b>Date of Birth/Age</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->patient->dob}}<br>{{\Carbon\Carbon::parse($newformat)->diff(\Carbon\Carbon::now())->format('%y years')}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Biological sex</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->gender}}</p>
                        </div>
                     </div>
                  </tr>
				   <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Address</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->address->address_1}}  {{$subscription->address->address_2 }} {{$order->patient->city}}  {{$order->patient->postcode}}</p>
                        </div>
                     </div>
                  </tr>
				   <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Phone</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->patient->phone}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Email</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->patient->user->email}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Medical Condition</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->product->category->name}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Medication (Strength/Quantity)</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->pack->name}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Dosage Instructions</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->subscription->duration}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Name of Prescriber</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->approved_by}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Order Status</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->order_status->title}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Price</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>£{{$order->pack->price}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Shipping</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->subscription->shipping_value}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Prescriber Notes for Pharmacy</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->notes_for_pharmacy}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Prescriber Notes for Patient</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$order->notes_for_customer}}</p>
                        </div>
                     </div>
                  </tr>
                  
               </tbody>
            </table>
         </div>
      </div>

      <?php 

               
foreach ($answers as $ans) {
            $subscription->risk_level = max($ans->risk, $subscription->risk_level);
         }
      ?>

      @if($subscription->risk_level == 0)
      <div class="card-header py-3 bg-safe">
         <h6 class="m-0 font-weight-bold safe">Questionnaire with responses:<b>Low</b></h6>
      </div>
      @elseif($subscription->risk_level == 2)
      <div class="card-header py-3 bg-risky">
         <h6 class="m-0 font-weight-bold risky">Questionnaire with responses:<b>High</b></h6>
      </div>
      @elseif($subscription->risk_level == 1)
      <div class="card-header py-3 bg-moderate">
         <h6 class="m-0 font-weight-bold moderate">Questionnaire with responses:<b>Moderate</b></h6>
      </div>
      @endif
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary"><b>Q/A</b></h6>
      </div>
      <div class="card-body">
         <div class="table">
            <table class="table" id="dataTable" width="100%" cellspacing="0">
               <tbody>
               @foreach($answers as $answer)
                  <tr>
                     <div class="row">
                        <td><div class="col-md-8">
                           {{$answer->question}}
                           
                        </div></td>
                        <td><div class="col-md-6">
                           <b>Answer:</b>
                           <li>{{$answer->ans}}</li>
                           
                           
                           @if($answer->risk == 0)
                              <div class="bg-safe">
                                 <h6 class="m-0 font-weight-bold safe"><b></b></h6>
                              </div>
                              @elseif($answer->risk == 1)
                              <div class="bg-risky">
                                 <h6 class="m-0 font-weight-bold risky"><b></b></h6>
                              </div>
                              @elseif($answer->risk == 2)
                              <div class="bg-moderate">
                                 <h6 class="m-0 font-weight-bold moderate"><b></b></h6>
                              </div>
                           @endif
                        </div>
                        </td>
                     </div>
                  </tr>
               @endforeach
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div>
@endsection