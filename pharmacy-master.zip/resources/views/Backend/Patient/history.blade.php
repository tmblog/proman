@extends('Backend.Doctor.index')
@section('page_content')
<div class="container-fluid">
   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-black">All Subscriptions of {{$subscription->patient->user->name}}</h6>
      </div>
      @if($subscription->subscription_status_id == 1)
      <div class="card-body bg-dark">
         <div class="row">
            <div class="col-md-12">
               <div class="py-3">
                  <h6 class="m-0 font-weight-bold text-white">You have already accepted the request</h6>
               </div>         
            </div>
         </div>
      </div>
      @endif

      @if($subscription->subscription_status_id == 2)
      <div class="card-body bg-danger">
         <div class="row">
            <div class="col-md-12">
               <div class="py-3">
                  <h6 class="m-0 font-weight-bold text-white">You have already rejected the request</h6>
               </div>         
            </div>
         </div>
      </div>
      @endif

      @if($subscription->subscription_status_id == 3)
      <div class="card-body">
         <div class="row">
            <div class="col-md-8">
               <p>Subscription description of <b>{{$subscription->patient->user->name}}</b> on <b>{{$subscription->updated_at}}</b></p>
            </div>
            <div class="col-md-4">
               <a href="{{route('subscription-approve',$subscription->id)}}" class="btn btn-sm btn-primary pull-right">Approve</a>
               <a href="{{route('subscription-reject',$subscription->id)}}" class="btn btn-sm btn-danger pull-right mr-2">Reject</a>
            </div>
         </div>
      </div>
      @endif

      @if($subscription->subscription_status_id == 4)
      <div class="card-body bg-dark">
         <div class="row">
            <div class="col-md-12">
               <div class="py-3">
                  <h6 class="m-0 font-weight-bold text-white">Subscription is paused by the user</h6>
               </div>         
            </div>
         </div>
      </div>
      @endif

      @if($subscription->subscription_status_id == 5)
      <div class="card-body bg-danger">
         <div class="row">
            <div class="col-md-12">
               <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-white">Subscription is canceled by the user</h6>
               </div>         
            </div>
         </div>
      </div>
      @endif

      @if($subscription->subscription_status_id == 6)
         @if($subscription->previous_status == 1)
         <div class="row">
            <div class="col-md-12">
               <div class="card-body bg-primary">
                  <div class="py-3">
                  <h6 class="m-0 font-weight-bold text-white">Previous subscription was accepted</h6>
                  </div>
               </div>
            </div>
         </div>

         @elseif($subscription->previous_status == 2)
         <div class="row">
            <div class="col-md-12">
               <div class="card-body bg-danger">
                  <div class="py-3">
                  <h6 class="m-0 font-weight-bold text-white">Previous subscription was rejected</h6>
                  </div>
               </div>
            </div>
         </div>
         @endif

      <div class="row">
         <div class="card-body">
            <div class="row">
               <div class="col-md-8">
                  <p>Subscription description of <b>{{$subscription->patient->user->name}}</b> on <b>{{$subscription->updated_at}}</b></p>
               </div>
               <div class="col-md-4">
                  <a href="{{route('subscription-approve',$subscription->id)}}" class="btn btn-sm btn-primary pull-right">Approve</a>
                  <a href="{{route('subscription-reject',$subscription->id)}}" class="btn btn-sm btn-danger pull-right mr-2">Reject</a>
               </div>
            </div>
         </div>
      </div>
      @endif

      @if($subscription->pending_reactivation == 1)
      <div class="card-body bg-warning">
         <div class="row">
            <div class="col-md-12">
            <div class="py-3">
               <h6 class="m-0 font-weight-bold text-white">User wants to reactivate the subscription</h6>
            </div>         
            </div>
         </div>
      </div>
      @endif
      <!-- </div> -->
   </div>
   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary"><b>Subscription Details</b></h6>
         <div class="float-right"><a href="/prescription/{{$subscription->id}}" target="_blank" class="btn btn-success">Prescription</a> </div>
      </div>
      <div class="card-body">
         <div class="table">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <tbody>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Prescription Date</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{\Carbon\Carbon::parse($subscription->created_at)->format('d/m/Y H:m')}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>ID Number</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->user->id}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Patient's Name</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->user->name}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Date of Birth</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->dob}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
						<?php
						$time = strtotime($subscription->patient->dob);
						$newformat = date('Y-m-d',$time);
					   ?>
                        <div class="col-md-4">
                           <p><b>Age</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{\Carbon\Carbon::parse($newformat)->diff(\Carbon\Carbon::now())->format('%y years')}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Biological sex</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->gender}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Address</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->address->address_1}} {{$subscription->address->address_2 }} {{$subscription->patient->city }} {{$subscription->patient->postcode}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Phone</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->phone}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Email</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->patient->user->email}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Medical Condition</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->product->category->name}}</p>
                        </div>
                     </div>
                  </tr>
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Medication (Strength/Quantity)</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->product->name}}</p>
                        </div>
                     </div>
                  </tr>
				  @if($subscription->edited_duration != null)
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Dosage Instructions</b></p>
                        </div>
                        <div class="col-md-8">
                           <p><del>{{$subscription->duration}}</del><b>(old)</b> &nbsp&nbsp {{$subscription->edited_duration}} <b>(Edited)</b></p>
                        </div>
                     </div>
                  </tr>
                  @else
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Dosage Instructions</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->duration}}</p>
                        </div>
                     </div>
                  </tr>
                  @endif
				  
				  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Name of Prescriber</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->approved_by}}</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Order Status</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->subscription_status->status}}</p>
                        </div>
                     </div>
                  </tr>
                  
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Price</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->pack->price}} GBP</p>
                        </div>
                     </div>
                  </tr>
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Ticket link for uvdesk</b></p>
                        </div>
                        <div class="col-md-8">
                        @if($subscription->zendex_link)
                           <p><a href="{{$subscription->zendex_link}}" target="_blank">{{$subscription->zendex_link}}</a></p>
                        @else
                           <p><a href="https://proman.uvdesk.com/apps/form-builder/en/form/html/88646094df91012a56094df9101351" target="_blank">https://proman.uvdesk.com/apps/form-builder/en/form/html/88646094df91012a56094df9101351</a></p>
                             <form method="post" action="/add-ticket/{{$subscription->id}}" >
                             @csrf
                             <div class="form-group">
                                 <label for=""><b>Ticket Number</b></label><br>
                                 <input required name="ticket" id="" cols="155" rows="3" class="form-control"/>
                              </div>
                              <button class="btn btn-primary" type="submit">Link ticket and start discussion</button>
                             </form> 
                              

                        @endif
                        </div>
                     </div>
                  </tr>

                  @if($subscription->is_edited == 1)
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Notes for doctor</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->notes_for_doctor_edit}}</p>
                        </div>
                     </div>
                  </tr>

                  @endif

                  @if($subscription->pending_reactivation == 1)
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Notes for doctor for reactivation</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->notes_for_doctor_reactivate}}</p>
                        </div>
                     </div>
                  </tr>
                  @endif

                  @if($subscription->subscription_status_id == 4)
                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Notes for doctor for Pausing Subscription</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{$subscription->notes_for_doctor_pause}}</p>
                        </div>
                     </div>
                  </tr>
                  @endif

                  <tr>
                     <div class="row">
                        <div class="col-md-4">
                           <p><b>Created_at</b></p>
                        </div>
                        <div class="col-md-8">
                           <p>{{\Carbon\Carbon::parse($subscription->updated_at)->format('d/m/Y H:m')}}</p>
                        </div>
                     </div>
                  </tr>
               </tbody>
            </table>
         </div>
      </div>

      <?php 

               
foreach ($answers as $ans) {
            $subscription->risk_level = max($ans->risk, $subscription->risk_level);
         }
      ?>

      @if($subscription->risk_level == 0)
      <div class="card-header py-3 bg-safe">
         <h6 class="m-0 font-weight-bold safe">Questionnaire with responses:<b>Low risk</b></h6>
      </div>
      @elseif($subscription->risk_level == 2)
      <div class="card-header py-3 bg-risky">
         <h6 class="m-0 font-weight-bold risky">Questionnaire with responses:<b>High Risk</b></h6>
      </div>
      @elseif($subscription->risk_level == 1)
      <div class="card-header py-3 bg-moderate">
         <h6 class="m-0 font-weight-bold moderate">Questionnaire with responses:<b>Moderate</b></h6>
      </div>
      @endif
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary"><b>Q/A</b></h6>
      </div>
      <div class="card-body">
         <div class="table">
            <table class="table" id="dataTable" width="100%" cellspacing="0">
               <tbody>
               @foreach($answers as $answer)
                  <tr>
                     <div class="row">
                        <td><div class="col-md-8">
                           {{$answer->question}}
                           
                        </div></td>
                        <td><div class="col-md-6">
                           <b>Answer:</b>
                           <li>{{$answer->ans}}</li>
                           
                           
                           @if($answer->risk == 0)
                              <div class="bg-safe">
                                 <h6 class="m-0 font-weight-bold safe"><b>Green</b></h6>
                              </div>
                              @elseif($answer->risk == 1)
                              <div class="bg-risky">
                                 <h6 class="m-0 font-weight-bold risky"><b>Red</b></h6>
                              </div>
                              @elseif($answer->risk == 2)
                              <div class="bg-moderate">
                                 <h6 class="m-0 font-weight-bold moderate"><b>Amber</b></h6>
                              </div>
                           @endif
                        </div>
                        </td>
                     </div>
                  </tr>
               @endforeach
               </tbody>
            </table>
         </div>
      </div>
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary"><b>Previous Records</b></h6>
      </div>
      <div class="card-body">
         <ul class="unorderd-list">
            <div class="table-responsive">
               <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                     <tr>
                        <th scope="col">#</th>
                        <th scope="col">Requested Date</th>
                        <th scope="col">Medical Condition</th>
                        <th scope="col">Medication</th>   
                        <th scope="col">Order Status</th>
                        <th scope="col">Medical Consultation Link</th>
                     </tr>
                  </thead>
                  <tbody>
                     @foreach($histories as $history)
                     <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$history->updated_at}}</td>
                        <td>{{$history->product->category->name}}</td>
                        <td>{{$history->product->name}}</td>
                        <td>{{$history->subscription_status->status}}</td>
                        <td>
                           <a href="{{route('subscription-show',$history->id)}}" title="view">View Details</a>
                        </td>
                     </tr>
                     @endforeach
                  </tbody>
               </table>
            </div>
         </ul>
      </div>
   </div>
</div>
@endsection