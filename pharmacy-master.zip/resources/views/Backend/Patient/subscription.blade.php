@extends('Backend.Patient.index')
@section('page_content')
<div class="container-fluid">
   <!-- Page Heading -->
   <!-- <h1 class="h3 mb-2 text-gray-800">Contact us request</h1> -->
   <!-- DataTales Example -->
   @if ($message = Session::get('success'))
      <div class="alert alert-success  alert-dismissible">
         <button type="button" class="close" data-dismiss="alert">×</button>   
         <strong>{{ $message }}</strong>
      </div>
   @endif

   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <h6 class="m-0 font-weight-bold text-primary">All Subscriptions</h6>
      </div>
      <div class="card-body">
         <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                  <th scope="col">#</th>
                  <th scope="col">Requested Date</th>
                  <th scope="col">Medicine Category</th>
                  <th scope="col">Pack name</th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                  </tr>
               </thead>
               <tfoot>
                  <tr>
                  <th scope="col">#</th>
                  <th scope="col">Requested Date</th>
                  <th scope="col">Medicine Category</th>
                  <th scope="col">Pack name</th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                  </tr>
               </tfoot>
               <tbody>
                   
               @foreach($patient->subscriptions as $subscription)
               <tr>
               <th>{{$loop->iteration}}</th>
               @if($subscription->is_edited)
                  <th>{{$subscription->updated_at}}</th>
                  @else
                  <th>{{$subscription->created_at}}</th>
                  @endif</th>
               <th>{{$subscription->product->category->name}}</th>
               <th>{{$subscription->pack->name}}
               </th>
               <th>{{$subscription->subscription_status->status}}</th>
               @if($subscription->subscription_status_id != 5)
               <th>
                  @if($subscription->subscription_status_id != 1 or $subscription->subscription_status_id != 3)
                  <a href="{{route('subscription-patient-edit',$subscription->id)}}" title="Edit Subscription"><i class="fas fa-edit"></i></a>
                  @endif
                  <a href="#" title="Cancel Subscription" data-toggle="modal" data-target="#cancelSubscriptionModal">
                     <i class="fas fa-power-off"></i>
                  </a>
                  
                  @if($subscription->subscription_status_id == 4 )
                  <a href="{{route('subscription-patient-reactivate',$subscription->id)}}" title="Activate Subscription"><i class="fas fa-play-circle"></i></a>
                  @endif

                  @if($subscription->subscription_status_id != 4)
                  <a href="{{route('subscription-patient-pause',$subscription->id)}}" title="Pause Subscription"><i class="fas fa-pause-circle"></i></a>
                  @endif
               </th>
               @else
               <th></th>
               @endif
               </tr>
               @endforeach
               </tbody>
            </table>
         </div>
      </div>
   </div>
      <!-- Pause Modal-->
   <div class="modal fade" id="cancelSubscriptionModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header bg-danger">
               <h5 class="modal-title text-white small" id="exampleModalLabel">Ready to Cancel the Subscription?</h5>
               <button class="close" type="button" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">×</span>
               </button>
            </div>
            <div class="modal-body">If you are confirm to cancel the the subscription,please select submit</div>
            <div class="modal-footer">
               <button class="btn btn-sm btn-secondary" type="button" data-dismiss="modal">Cancel</button>
               <a href="{{route('subscription-patient-post-cancel',$subscription->id)}}" class="btn btn-sm btn-danger" onclick="event.preventDefault(); document.getElementById('cancel-subscription').submit();">
               Submit
               </a>
               <form id="cancel-subscription" action="{{route('subscription-patient-post-cancel',$subscription->id)}}" method="POST">
                  @csrf
               </form>
            </div>
         </div>
      </div>
   </div>
</div>

@endsection