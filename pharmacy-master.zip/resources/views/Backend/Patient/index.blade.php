<!DOCTYPE html>
<html lang="en">
@include('Backend.Layouts.header')
<body id="page-top">
  <div id="wrapper">
  
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

      @include('Backend.Patient.Partials.nav')

        @yield('page_content')
        
		<div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                  <th scope="col">#</th>
				  <th scope="col">Full Name</th>
				  <th scope="col">DOB/Age</th>
				  <th scope="col">Gender</th>
                  <th scope="col">Address</th>
                  <th scope="col">Phone</th>
                  </tr>
               </thead>
               
               <tbody>
                   
               
               <tr>
               <th>{{$patient->user_id}}</th>
			   <th>Name</th>
			   <th>{{$patient->dob}}</th>
			   <th>{{$patient->gender}}</th>
			   <th>{{$patient->city}} {{$patient->postcode}}</th>
			   <th>{{$patient->phone}}</th>
               </tr>
               </tbody>
            </table>


      </div>
      <!-- End of Main Content -->

      @include('Backend.Layouts.footer')

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>  
@include('Backend.Layouts.logout_modal')
@include('Backend.Layouts.footer_links')

@stack('scripts')

</body>
</html>