@extends('Backend.Doctor.index')
@section('page_content')
<div class="container-fluid">
   <!-- Page Heading -->
   <!-- <h1 class="h3 mb-2 text-gray-800">Contact us request</h1> -->
   <!-- DataTales Example -->

   @if ($message = Session::get('success'))
      <div class="alert alert-success  alert-dismissible">
         <button type="button" class="close" data-dismiss="alert">×</button>   
         <strong>{{ $message }}</strong>
      </div>
   @endif


   <div class="card shadow mb-4">
      <div class="card-header py-3">
         <div class="row">
            <div class="col-md-8">
               <h6 class="m-0 font-weight-bold text-primary">
                  Subscription of {{$subscription->patient->user->name}} on the date of 
                  <span>{{$subscription->created_at}}</span>
               </h6>
            </div>
            <div class="col-md-4">
            <a href="{{redirect()->getUrlGenerator()->previous()}}" class="btn btn-sm btn-dark pull-right">Go Back</a>
            </div>
         </div>
      </div>
   </div>

   <div class="card shadow mb-4">
      <div class="card-body py-3">
         <form action="{{route('subscription-post-reject',$subscription)}}" method="post">
            @csrf

            <div class="form-group">
               <label for=""><b>Notes For Customer*</b></label><br>
               <textarea name="notes_for_customer" id="" cols="155" rows="3" class="form-control"></textarea>
            </div>

            <div class="form-group">
               <button class="btn btn-sm btn-dark">Reject</button>
            </div>
         </form>
      </div>
   </div>
</div>

@endsection