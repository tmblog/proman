<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<style type="text/css">
#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  padding: 40px;
  width: 70%;
  min-width: 300px;
}

/* Style the input fields */
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

/* Mark the active step: */
.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
</style>
@include('Frontend.Master.header')

<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		@include('Frontend.Master.nav')
        <!-- #header end -->

		<!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">

						<div class="row col-mb-50 my-0 py-0">
							<form id="regForm" action="#">

							<h1>Choose your products</h1>
							
							<div class="tab">
							
							<div class="accordion" id="accordionExample">
							  <div class="card">
								<div class="card-header" id="headingOne">
								  <h5 class="mb-0">
									<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
									  Sildenafil
									</button> <span class="float-right">From £12.99</span>
								  </h5>
								</div>

								<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
								  <div class="card-body">
									Sildenafil is our most popular erectile dysfunction treatment due to its clinically proven effects and affordable price. It works by establishing reliable blood flow to the penis, ensuring a strong erection when you need one.
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
									  <label class="form-check-label" for="exampleRadios1">
										8 Tablets 50g £20
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
									  <label class="form-check-label" for="exampleRadios2">
										8 Tablets 25g £15
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3" checked>
									  <label class="form-check-label" for="exampleRadios3">
										12 Tablets 50g £30
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="option4">
									  <label class="form-check-label" for="exampleRadios4">
										12 Tablets 25g £25
									  </label>
									</div>

								  </div>
								</div>
							  </div>
							  <div class="card">
								<div class="card-header" id="headingTwo">
								  <h5 class="mb-0">
									<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
									  Tadalafil Daily
									</button> <span class="float-right">From £12.99</span>
								  </h5>
								</div>
								<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
								  <div class="card-body">
									Tadalafil Daily gives you the freedom to enjoy spontaneous sex without needing to plan ahead. It’s a clinically proven daily tablet that keeps your body topped up with a steady supply of Tadalafil, allowing you to get an erection whenever you need one.
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tdRadios" id="tdRadios1" value="option1">
									  <label class="form-check-label" for="tdRadios1">
										8 Tablets 50g £20
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tdRadios" id="tdRadios2" value="option2">
									  <label class="form-check-label" for="tdRadios2">
										8 Tablets 25g £15
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tdRadios" id="tdRadios3" value="option3" checked>
									  <label class="form-check-label" for="tdRadios3">
										12 Tablets 50g £30
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tdRadios" id="tdRadios4" value="option4">
									  <label class="form-check-label" for="tdRadios4">
										12 Tablets 25g £25
									  </label>
									</div>

								  </div>
								</div>
							  </div>
							  <div class="card">
								<div class="card-header" id="headingThree">
								  <h5 class="mb-0">
									<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
									  Tadalafil
									</button> <span class="float-right">From £12.99</span>
								  </h5>
								</div>
								<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
								  <div class="card-body">
									Clinically proven to help erections stay harder for longer, tadalafil gives you greater flexibility when planning to have sex. It lasts for 36 hours (9 times longer than sildenafil), so you can enjoy sex without needing to take a tablet immediately beforehand.
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tRadios" id="tRadios1" value="option1">
									  <label class="form-check-label" for="tRadios1">
										8 Tablets 50g £20
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tRadios" id="tRadios2" value="option2">
									  <label class="form-check-label" for="tRadios2">
										8 Tablets 25g £15
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tRadios" id="tRadios3" value="option3" checked>
									  <label class="form-check-label" for="tRadios3">
										12 Tablets 50g £30
									  </label>
									</div>
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="tRadios" id="tRadios4" value="option4">
									  <label class="form-check-label" for="tRadios4">
										12 Tablets 25g £25
									  </label>
									</div>

								  </div>
								</div>
							  </div>
							  <div class="card">
								<div class="card-header" id="headingThree">
								  <h5 class="mb-0">
									<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
									  Viagra Connect
									</button> <span class="float-right">From £12.99</span>
								  </h5>
								</div>
								<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
								  <div class="card-body">
									Viagra Connect is the over-the-counter version of Viagra. It is the first non-prescription medication available in the UK to treat erectile dysfunction. It works by establishing reliable blood flow to the penis, ensuring a strong erection, when you need it.
									<hr>
									<div class="form-check">
									  <input class="form-check-input" type="radio" name="vRadios" id="vRadios1" value="option1" checked>
									  <label class="form-check-label" for="vRadios1">
										8 Tablets 50g £20
									  </label>
									</div>

								  </div>
								</div>
							  </div>

							</div>

							</div>

							<div class="tab">Account information:
							  <p><input placeholder="Email..." oninput="this.className = ''"></p>
							  <p><input placeholder="Password..." oninput="this.className = ''"></p>
							</div>

							<div class="tab">Personal information:<br>
							<p>We are required to confirm the identity of our members. Any incorrect details will cause delays to your order.</p>
							  <p><input placeholder="legal First name..." oninput="this.className = ''"></p>
							  <p><input placeholder="Legal Last name..." oninput="this.className = ''"></p>
							  <p><input placeholder="Date of birth" oninput="this.className = ''"></p>
							  <p><input placeholder="Phone number" oninput="this.className = ''"></p>
							  <p><input placeholder="Gender dropdwon" oninput="this.className = ''"></p>
							</div>

							<div class="tab">Shipping address:
							  <p><input placeholder="Postcode" oninput="this.className = ''"></p>
							  <p><input placeholder="City" oninput="this.className = ''"></p>
							  <p><input placeholder="Address" oninput="this.className = ''"></p>
							</div>

							<div class="tab">Terms:
							  <p><input placeholder="Terms checkbox" oninput="this.className = ''"></p>
							  <p><input placeholder="Offer checkbox" oninput="this.className = ''"></p>
							</div>

							<div style="overflow:auto;">
							  <div style="float:right;">
								<button type="button" id="prevBtn" class="button button-3d button-large button-rounded button-amber" onclick="nextPrev(-1)">Previous</button>
								<button type="button" id="nextBtn" class="button button-3d button-large button-rounded button-green" onclick="nextPrev(1)">Next</button>
							  </div>
							</div>

							<!-- Circles which indicates the steps of the form: -->
							<div style="text-align:center;margin-top:40px;">
							  <span class="step"></span>
							  <span class="step"></span>
							  <span class="step"></span>
							  <span class="step"></span>
							  <span class="step"></span>
							</div>

							</form> 

						</div>
				
				</div>
			</div>
		</section>
		@yield('page_content')
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		@include('Frontend.Master.footer')
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>
	<!-- JavaScripts
	============================================= -->
	@include('Frontend.Master.footer_links')
    @stack('scripts')
<script type="text/javascript">
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
</script>
</script>
</body>
</html>