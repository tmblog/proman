
<script> window.baseUrl = '{{url('/')}}';</script>
<script> window.storageUrl = '{{env('STORAGE_URL')}}';</script>
<script> window.publicUrl = '{{env('PUBLIC_PATH')}}';</script>
<script> window.token = '{{@csrf_token()}}';</script>
<script> window.id = '';</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="{{env('PUBLIC_PATH')}}/frontend/js/plugins.min.js" type="text/javascript"></script>
<script src="{{env('PUBLIC_PATH')}}/frontend/js/components/datepicker.js" type="text/javascript"></script>

<!-- Footer Scripts
============================================= -->
<script src="{{env('PUBLIC_PATH')}}/frontend/js/functions.js"></script>
