<!DOCTYPE html>
<html dir="ltr" lang="en-US">
@include('Frontend.Master.header')
<link href="https://unpkg.com/survey-jquery@1.8.37/modern.css" type="text/css" rel="stylesheet" />

<meta name="description" content="Competitive prices on Men's medications and treatments, order online with free consultation. ProMan health is an online Pharmacy for men's health."/>
<!-- Document Title
============================================= -->
<title>Free Health Consulations | ProMan Health</title>

</head>
<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		@include('Frontend.Master.nav')
		<!-- #header end -->

		@if(!\Auth::check())
			<p  class="text-center alert alert-info">Returning customer? <a href="/login" style="color: blue;">Login here</a></p>
		@endif
		<!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap section light">
				<div class="container clearfix">

					<div class="row my-0">
						<div class="col-md-12">
							<div id="surveyContainer"></div>
						</div>
					</div>

				</div>
			</div>
		</section>
		@yield('page_content')
		<!-- #content end -->

		<!-- Footer
		============================================= -->
		@include('Frontend.Master.footer')
		<!-- #footer end -->

	</div>
	<!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>
	<!-- JavaScripts
	============================================= -->
	@include('Frontend.Master.footer_links')
	@stack('scripts')

	<script src="https://unpkg.com/survey-jquery@1.8.34/survey.jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
	<script type="text/javascript">
		Survey.StylesManager.applyTheme("modern");
		var surveyJSON = {!! $category->questions !!};
		console.log(surveyJSON)

		function sendDataToServer(survey) {
			//send Ajax request to your web server.
			let path = "{{ route('store-answer',$category->slug) }}";
			axios.post(path, {
					data: survey.data,
					product_id: {{$product_id}},
					pack_id: {{$pack_id}}
				})
				.then(function(response) {
					window.location = response.data;
					console.log(response);
				})
				.catch(function(error) {
					console.log(error);
				});
		}

		var survey = new Survey.Model(surveyJSON);
		$("#surveyContainer").Survey({
			model: survey,
			onComplete: sendDataToServer
		});
	</script>
</body>

</html>