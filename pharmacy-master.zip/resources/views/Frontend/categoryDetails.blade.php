<!DOCTYPE html>
<html dir="ltr" lang="en-US">
@include('Frontend.Master.header')
<meta name="description" content="{{$category->meta_desc}}"/>
<!-- Document Title
============================================= -->
<title>ProMan Health | {{$category->name}} Treatments</title>

</head>
<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		@include('Frontend.Master.nav')
        <!-- #header end -->

		<!-- Page Title
		============================================= -->
		<section id="page-title" class="bg-color page-title-dark">

			<div class="container clearfix">
				<h1>{{$category->name}}</h1>
			</div>

		</section><!-- #page-title end -->
		
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">

					<div class="row col-mb-50 mb-0">
						<div class="col-sm-12">
							<div class="card">
								<div class="row card-body">
								   <div class="col-sm-8">
									   <h1 class="card-title">{{$category->name}}</h1>
										<span class="card-text">{{$category->description}}</span>
									</div>
									<img class="col-sm-4" src="/storage/{{$category->image}}" alt="/storage/{{$category->image}} image"/>
								</div>
							</div>
						</div>

					</div>
				
					<div class="row col-mb-50 mb-0">
						@foreach($category->products as $product)
							<div class="col-sm-6 col-lg-3">
								
								<div class="card" >
								  <img src="/storage/{{$product->image}}" class="card-img-top" alt="/storage/{{$product->image}} image">
								  <div class="card-body">

									<a href="/treatments/{{$category->slug}}/{{$product->slug}}" class="button button-mini button-border button-border-thin button-red btn-block">{{$product->name}} <i class="icon-circle-arrow-right"></i></a>
								  </div>
								</div>

							</div>
						@endforeach
					</div>

					<div class="row col-mb-50 mb-0">
						<div class="col-sm-12">
							<div class="card">
								<div class="row card-body">
								   <div class="col-sm-12">
										<span class="card-text">{!! $category->treatment_more_desc !!}</span>
									</div>
									
								</div>
							</div>
						</div>

					</div>

				</div>

			</div>
		</section>

		@yield('page_content')
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		@include('Frontend.Master.footer')
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	@include('Frontend.Master.footer_links')
    @stack('scripts')
</body>
</html>