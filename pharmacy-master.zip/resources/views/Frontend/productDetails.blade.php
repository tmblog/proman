<!DOCTYPE html>
<html dir="ltr" lang="en-US">
@include('Frontend.Master.header')
<meta name="description" content="{{$product->meta_desc}}"/>
<!-- Document Title
============================================= -->
<title>ProMan Health | {{$product->name}} Buy Online</title>

</head>
<body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		@include('Frontend.Master.nav')
        <!-- #header end -->

		<!-- Page Title
		============================================= -->
		<section id="page-title" class="page-title-dark">

			<div class="container clearfix">
				<h1>{{$product->name}}</h1>
				<span>{!!$product->description!!}</span>
			</div>

		</section><!-- #page-title end -->
		
		<div class="section mt-0" style="background:#FFF;">

			<div class="container clearfix">

				<div class="row justify-content-between">
					<div class="col-lg-4">
						<div class="heading-block bottommargin-sm border-bottom-0">
							<h4>{{$product->name}}</h4>
							<span>Lorem ipsum dolor sit amet, consecte adipisicing elit molestiae non.</span>
						</div>
					<img src="/storage/{{$product->image}}" class="card-img-top" alt="/storage/{{$product->image}} image">
					</div>
					<div class="col-lg-8">
						<div class="opening-table">
							<div class="heading-block bottommargin-sm border-bottom-0">
								<!-- <h4>Opening Hours</h4> -->
								<span>Lorem ipsum dolor sit amet, consecte adipisicing elit molestiae non.</span>
							</div>
							<?php
								$strengths = [];
								foreach ($product->packs as $pack) {
									array_push($strengths, $pack->strength->name);
								}
								$strengths = array_unique($strengths);
							?>
							<label for="strength" class="col-sm-6 col-md-3">Choose</label>
							<select name="strength" class="form-control mb-3" id="strength" onchange="strengthSelected(this.value);">
								<option>Choose Dosage</option>
							@foreach($strengths as $strength)
								<option value="{{$strength}}">{{$strength}}</option>
							@endforeach
							</select>
							<script>
								var allPacks = {!! $product->packs !!};
								var selectedPacks = [];
								function strengthSelected(strength){
									//console.log(strength);
									selectedPacks = [];
									allPacks.forEach(element => {
										if(element.strength.name == strength){
											selectedPacks.push(element);
										}
									});
									console.log(selectedPacks);
									var x="";
									for (var i = 0; i < selectedPacks.length; i++) {
											console.log(selectedPacks[i].price);
											x += '<label for="'+selectedPacks[i].id+'" class="col-sm-6 col-md-3"><div class="text-center border"><input type="radio" name="{{$product->id}}" class="required mt-3" id="'+selectedPacks[i].id+'" autocomplete="off" data-price="'+selectedPacks[i].price+'" value="'+selectedPacks[i].id+'" data-product="'+{{$product->id}}+'" data-pack="'+selectedPacks[i].id+'" onclick="setConsult(this.getAttribute(\'data-product\'), this.getAttribute(\'data-pack\'));"><div class="pricing-title bg-transparent"><h5 class="nott ls0">'+selectedPacks[i].tablets+' tablets</h5><span class="price-unit">'+selectedPacks[i].price+'</span></div></div></label>';
											
										}
									//selectedPacks.forEach(pack => x += '<p>'+pack.price+'</p>');
										$("#packs").empty().html(x);
								}

							</script>

							<div id="packs" class="">
							</div>

							 <a href="#" class="button button-small text-right btn-block button-amber" id="startConsult">Start Consultation<i class="icon-circle-arrow-right"></i></a>
						</div>
						
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12">
					{!!$product->info!!}
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12">
					{!!$product->more_desc!!}
					</div>
				</div>
			</div>

		</div>

		@yield('page_content')
        <!-- #content end -->
        
		<!-- Footer
		============================================= -->
		@include('Frontend.Master.footer')
        <!-- #footer end -->

	</div>
    <!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
	============================================= -->
	@include('Frontend.Master.footer_links')
    @stack('scripts')
	<script type="text/javascript">

        function setConsult(data_product, data_pack){       
		   var link = document.getElementById("startConsult");
		   link.setAttribute("href", "/treatments/{{$category->slug}}/consultation?product="+data_product+"&pack="+data_pack);
		   return false;
        }

    </script>
</body>
</html>
