@extends('welcome')
@section('page_content')

<!-- Content
============================================= -->
<section id="content">
   <div class="content-wrap pb-0">
      <div class="container clearfix">
         <div class="row justify-content-center mb-5">
            <div class="col-lg-7 center">
               <div class="heading-block">
                  <h3 class="nott mb-3 font-weight-semibold ls0">{{$category['name']}}/{{$product['name']}}</h3>
                  <!-- <span class="text-black-50">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate corporis, facilis assumenda optio consequuntur amet iure, quidem animi nam inventore!</span> -->
               </div>
            </div>
         </div>
      </div>
      <div class="clear"></div>
      <div class="section section-features bg-transparent mt-0 p-0 clearfix">
         <div class="container clearfix">
            <div class="row col-mb-50 col-mb-lg-80">
            @foreach($product->packs as $pack)
               <div class="col-md-4">
                  <div class="feature-box media-box">
                     <div class="fbox-icon position-relative mb-4" style="background-image: url('demos/movers/images/featured-img/1.jpg');">
                        <i class="icon-line2-home"></i>
                     </div>
                     <div class="fbox-content">
                        <h3 class="font-weight-semibold">{{$pack->name}}</h3>
                        <p class="text-muted">{{$pack->tablets}}&nbsp pieces</p>
                        <p class="text-muted">{{$pack->price}} GBP</p>
                        <a href="{{route('product-questions',[$category['slug'],$product['slug'],$pack->id])}}">See Products</a>
                        <p class="text-muted">{{$product['description']}}</p>
                     </div>
                  </div>
               </div>
               @endforeach
            </div>
         </div>
      </div>
   </div>
</section>
<!-- #content end -->
@endsection