<!DOCTYPE html>
<html dir="ltr" lang="en-US">
   @include('Frontend.Master.header')
<script src="https://www.paypal.com/sdk/js?client-id=sb&currency=GBP&components=buttons,funding-eligibility"></script>
<meta name="description" content="Competitive prices on Men's medications and treatments, order online with free consultation. ProMan health is an online Pharmacy for men's health."/>
<!-- Document Title
============================================= -->
<title>Free Health Consulations | ProMan Health</title>
</head>
   <body class="stretched page-transition" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='https://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='https://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">
      <!-- Document Wrapper
         ============================================= -->
      <div id="wrapper" class="clearfix">
         <!-- Header
            ============================================= -->
         @include('Frontend.Master.nav')
         <!-- #header end -->
         <!-- Content
            ============================================= -->
         <section id="content">
            
               <div class="container clearfix">
                  <div class="col-mb-50 my-0 py-0">
                     <form action="{{ route('subscription-store') }}" method="post" id="shipping-form">
                        @csrf
                        <h1>Personal details</h1>
                        <!--if auth check is true then hide the div-->
                        <?php 
                        $name="";
                        $email="";
                        $pass="";
                        $session_id = "";
                           if(\Auth::check()){
                              $name=\Auth::user()->name;
                              $email=\Auth::user()->email;
                              $pass="**********";
                              
                           }
                           
                        ?>
                        <div class="row">
							<div class="col-md">
								<div class="col-12 form-group">
									<label>First Name:</label>
									<input type="text" value="{{ $name }}" name="firstname" id="firstname" class="form-control required">
								</div>
								<div class="col-12 form-group">
									<label>Last Name:</label>
									<input type="text" name="lastname" id=="lastname" class="form-control required">
								</div>
								<div class="col-12 form-group">
									<label>Phone:</label><br>
									<input type="text" name="phone" id="phone" class="form-control required" placeholder="0207 000 0000">
								</div>
								<div class="col-12 form-group">
									<label>Date of Birth:</label>
									<input type="text" name="dob" id="dob" class="form-control datepicker required">
								</div>
								<div class="col-6 form-group">
									<label>Gender:</label>
									<select class="form-select form-control required" name="gender" id="gender">
										<option value="male">Male</option>
										<option value="female">Female</option>
									</select>
								</div>
							</div>
							<div class="col-md">
								<div class="col-12 form-group">
									<label>Street Address:</label>
									<input type="text" name="address_1"  id="address_1" class="form-control required">
								</div>
								<div class="col-12 form-group">
									<label>City:</label>
									<input type="text" name="city" id="city" class="form-control required">
								</div>
								<div class="col-12 form-group">
									<label>Post Code:</label>
									<input type="text" name="postcode" id="postcode" class="form-control required">
								</div>
								<div class="col-12 form-group">
									<label>Email:</label>
									<input type="email" name="email" id="email" value="{{ $email }}" class="form-control required" placeholder="user@company.com">
								</div>
								<div class="col-12 form-group">
									<label>Password:</label>
									<input type="password" name="password" id="password" value="{{ $pass }}" class="form-control required">

									<input type="hidden" value="{{$product_id}}" name="product_id">
                           			<input type="hidden" value="{{$pack_id}}" name="pack_id">
								</div>
							</div>
							
						  </div>
						  <div class="col-lg">
								<button type="submit" id="submitButton" class="button button-3d button-large button-rounded button-green float-right">Next</button>
						  </div>
						
                     </form>
                  </div>
               </div>
            
         </section>
         @yield('page_content')
         <!-- #content end -->
         <!-- Footer
            ============================================= -->
         @include('Frontend.Master.footer')
         <!-- #footer end -->
      </div>
      <!-- #wrapper end -->
      <!-- Go To Top
         ============================================= -->
      <div id="gotoTop" class="icon-angle-up"></div>
      <!-- JavaScripts
         ============================================= -->
      @include('Frontend.Master.footer_links')
      @stack('scripts')
	  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
	<script>
		jQuery(document).ready( function(){

			$('.datepicker').datepicker({
				autoclose: true,
				format: 'dd/mm/yyyy'
			});

		});

		$('#submitButton').click(function(ev) {
			//ev.preventDefault();
				$("#shipping-form").validate({
					focusInvalid: true,
					rules: {
						"firstname": {
							required: true
						},
						"lastname": {
							required: true
						},
						"address_1": {
							required: true
						},
						"postcode": {
							required: true
						},
						"email": {
							required: true,
							email: true
						},
						"password": {
							required: true
						}
					}
				});
			});
		
			/*$("#shipping-form").validate({
			  debug: true
			});*/
	</script>
   </body>
</html>