@extends('layouts.app')
@section('page_content')
<!-- Content
   ============================================= -->

   <?php
   $s = \App\Subscription::where('id', $subscription->id)->with(['product', 'pack'])->firstOrFail();

   ?>

<section id="content">
   <div class="content-wrap pb-0">
   <div class="container clearfix">
      <div class="row justify-content-center mb-5">
         <div class="col-lg-7 center">
            <!--<div class="heading-block">
               <h3 class="nott mb-3 font-weight-semibold ls0">Checkout Page</h3>
            </div>-->
         </div>
      </div>
   </div>
   <form action="" id="paypal-form">
   </form>
   <div class="clear"></div>
   <div class="section section-features bg-transparent mt-0 p-0 clearfix">
      <div class="container clearfix">
         <div class="row">
            <div class="col-lg-6 mx-auto">
               <div class="card ">
                  <div class="card-header">
                     <div class="bg-white shadow-sm pt-4 pl-2 pr-2 pb-2">
                        <!-- Credit card form tabs -->
                        <ul role="tablist" class="nav bg-light nav-pills rounded nav-fill mb-3">
                           <!-- <li class="nav-item"> <a data-toggle="pill" href="#subscription" class="nav-link active "> <i class="fas fa-credit-card mr-2"></i> Subscribe </a> </li> -->
                           <!-- <li class="nav-item"> <a data-toggle="pill" href="#one-off" class="nav-link "> <i class="fab fa-paypal mr-2"></i>One Off</a> </li> -->
                        </ul>
                     </div>
                     <!-- End -->
                     <!-- Credit card form content -->
                     <div class="tab-content">
                        <!-- credit card info-->
                        <div id="subscription" class="tab-pane fade show active pt-3">
                           <form action="{{route('paypal.redirect')}}" method="post" role="form">
                              @csrf
                              <div class="form-group">
                                 <label for="duration">
                                    <h6>Select shipping method</h6>
                                 </label>
                                 <select name="shipping_value" required>
                                    <option value="First Class">First Class</option>
                                    <option value="Next Day">Next Day</option>
                                 </select>
                              </div>
                              <div class="form-group">
                                 <label for="duration">
                                    <!-- <h6>Dosage for repeatation*</h6> -->
                                 </label>
                                 <input type="hidden" name="duration" placeholder="Dosage for repeatation" required class="form-control " value="50"> 
                              </div>
                              <div class="form-group">
                                 <label for="interval">
                                    <!-- <h6>Dosage Interval*</h6> -->
                                 </label>
                                 <div class="input-group">
                                    <input type="hidden" name="interval" placeholder="Dosage Interval" class="form-control" value="4">
                                 </div>
                              </div>
                              
                             
                              </div>
                              <input type="hidden" name="subscription" value="{{$subscription->id}}">
                              <div class="card-footer">
                                 <button type="submit" class="subscribe btn btn-warning btn-block shadow-sm"> <img src="/paypal.png" style="max-width:25%;"/></button>
                                 <p class="text-center"><small><i><b>Powered by</b></i> <img src="/paypal_powered.png" style="max-width:6%;"/></small></p>
                           </form>
                           </div>
                        </div>
                        <!-- End -->
                        <!-- Paypal info -->
                        <!-- <div id="one-off" class="tab-pane fade pt-3">
                           <div class="form-group">
                              <label for="interval">
                                 <h6>Address 1</h6>
                              </label>
                              <div class="input-group">
                                 <input type="text" name="address_1" id="address_1" placeholder="Shipping address 1" class="form-control">
                              </div>
                           </div>
                           <div class="form-group">
                              <label for="interval">
                                 <h6>Address 2(Optional)</h6>
                              </label>
                              <div class="input-group">
                                 <input type="text" name="address_2" placeholder="Shipping address 2" class="form-control">
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-5 mb-3">
                                 <label for="country">Country</label>
                                 <select class="custom-select d-block w-100" id="country" required="" name="country">
                                    <option value="">Choose...</option>
                                    <option>United States</option>
                                 </select>
                                 <div class="invalid-feedback">
                                    Please select a valid country.
                                 </div>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="state">State</label>
                                 <select class="custom-select d-block w-100" id="state" required="" name="state">
                                    <option value="">Choose...</option>
                                    <option>California</option>
                                 </select>
                                 <div class="invalid-feedback">
                                    Please provide a valid state.
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="zip">Zip</label>
                                 <input type="text" class="form-control" id="zip" placeholder="" required="" name="zip">
                                 <div class="invalid-feedback">
                                    Zip code required.
                                 </div>
                              </div>
                           </div>
                           <div id="paypal-button"></div>
                           <script>
                              paypal.Buttons({
                              	env: 'sandbox', // Or 'production'
                              	// Set up the payment:
                              	// 1. Add a payment callback
                              	style:{
                              		color: 'blue',
                              layout: 'horizontal',
                              tagline: 'false'
                              	},
                              	
                              	createOrder: function(data, actions) {
                              		// 2. Make a request to your server
                              		// var formData = new FormData($('#paypal-form'));
                              		return axios({
                              			method: 'post',
                              			url: '/api/paypal-create-payment',
                              			data: {
                                          subscription_id: "{{$subscription->id}}",
                                          address_1:$('#address_1').val(),
                                          country:$('#country').val()
                                       },
                              		}).then(function(res) {
                              			console.log(res);
                              			return res.data.id;
                              		}).catch(function(result) {
                              			console.log(result.response);
                              		});
                              
                              	},
                              	// Execute the payment:
                              	// 1. Add an onAuthorize callback
                              	onApprove: function(data, actions) {
                              
                              		return axios({
                              			method: 'post',
                              			url: '/api/paypal-execute-payment',
                              			data: {
                              				paymentID: data.paymentID,
                              				payerID: data.payerID,
                              				orderID: data.orderID,
                              				paymentToken: data.paymentToken,
                              			},
                              		}).then(function(res) {
                              			console.log(res);
                              			window.location.href = "{{route('payment.success')}}";
                              			return res.data.id;
                              		}).catch(function(result) {
                                       window.location.href = "{{route('payment.failed')}}";
                              			console.log(result.response);
                              		});         		
                              	}
                              }).render('#paypal-button');
                           </script>
                        </div> -->
                        <!-- End -->
                        <!-- End -->
                     </div>
                  </div>
               </div>
            </div>
            <!-- <div class="col-lg-6 mx-auto"></div> -->
            <div class="col-lg-6 mx-auto">
               <div class="bg-pay p-3">
                  <span class="font-weight-bold">Order Recap</span>
                  <div class="d-flex justify-content-between mt-2"> <span class="fw-500">{{$s->product->name}} - {{$s->pack->name}}</span> <span>£{{$s->pack->price}}</span> </div>
                  
                  <hr>
                  <div class="d-flex justify-content-between mt-2"> <span class="fw-500">Total </span> <span class="text-success">£{{$s->pack->price}}</span> </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- #content end -->
@endsection